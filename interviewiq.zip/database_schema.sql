-- InterviewIQ PostgreSQL Relational Database Schema
-- Managed via Drizzle ORM (src/db/schema.ts) on Cloud SQL PostgreSQL

CREATE TABLE IF NOT EXISTS profiles (
  id SERIAL PRIMARY KEY,
  uid TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL DEFAULT 'Student',
  target_role TEXT NOT NULL DEFAULT 'Software Engineer',
  college_name TEXT NOT NULL DEFAULT 'B.Tech Computer Science',
  graduation_year TEXT NOT NULL DEFAULT '2026',
  experience_level TEXT NOT NULL DEFAULT 'Beginner',
  bio TEXT NOT NULL DEFAULT 'Preparing for technical and behavioral campus placements.',
  email_alerts_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS questions (
  id SERIAL PRIMARY KEY,
  question_code TEXT NOT NULL UNIQUE,
  question_text TEXT NOT NULL,
  topic TEXT NOT NULL,
  job_role TEXT NOT NULL,
  applicable_roles JSONB NOT NULL DEFAULT '[]'::jsonb,
  category TEXT NOT NULL,
  difficulty TEXT NOT NULL,
  expected_answer TEXT NOT NULL,
  evaluation_keywords JSONB NOT NULL DEFAULT '[]'::jsonb,
  evaluation_criteria TEXT NOT NULL,
  marks INTEGER NOT NULL DEFAULT 10,
  created_by_uid TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS interviews (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  user_uid TEXT NOT NULL,
  job_role TEXT NOT NULL,
  category TEXT NOT NULL,
  initial_difficulty TEXT NOT NULL,
  current_difficulty TEXT NOT NULL,
  total_questions INTEGER NOT NULL,
  answered_count INTEGER NOT NULL DEFAULT 0,
  time_limit_minutes INTEGER NOT NULL,
  duration_seconds INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'in_progress',
  total_score REAL NOT NULL DEFAULT 0,
  max_score REAL NOT NULL DEFAULT 0,
  percentage REAL NOT NULL DEFAULT 0,
  adaptive_history JSONB NOT NULL DEFAULT '[]'::jsonb,
  started_at TIMESTAMP NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS interview_answers (
  id SERIAL PRIMARY KEY,
  interview_id INTEGER NOT NULL REFERENCES interviews(id) ON DELETE CASCADE,
  question_id INTEGER NOT NULL REFERENCES questions(id),
  user_uid TEXT NOT NULL,
  question_order INTEGER NOT NULL,
  difficulty_at_time TEXT NOT NULL,
  user_answer TEXT NOT NULL DEFAULT '',
  draft_answer TEXT NOT NULL DEFAULT '',
  score REAL NOT NULL DEFAULT 0,
  max_marks INTEGER NOT NULL DEFAULT 10,
  is_submitted BOOLEAN NOT NULL DEFAULT FALSE,
  correctness_level TEXT NOT NULL DEFAULT 'Pending',
  feedback TEXT NOT NULL DEFAULT '',
  matched_keywords JSONB NOT NULL DEFAULT '[]'::jsonb,
  missing_concepts JSONB NOT NULL DEFAULT '[]'::jsonb,
  suggested_improvements TEXT NOT NULL DEFAULT '',
  score_breakdown JSONB NOT NULL DEFAULT '{"keywordRelevance":0,"conceptualUnderstanding":0,"completeness":0,"relevance":0}'::jsonb,
  adaptive_message TEXT NOT NULL DEFAULT '',
  next_difficulty TEXT NOT NULL DEFAULT 'Beginner',
  time_spent_seconds INTEGER NOT NULL DEFAULT 0,
  answered_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS performance_records (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  user_uid TEXT NOT NULL,
  interview_id INTEGER NOT NULL REFERENCES interviews(id) ON DELETE CASCADE,
  topic TEXT NOT NULL,
  category TEXT NOT NULL,
  difficulty TEXT NOT NULL,
  questions_attempted INTEGER NOT NULL,
  correct_count INTEGER NOT NULL,
  average_score REAL NOT NULL,
  accuracy_percentage REAL NOT NULL,
  avg_time_seconds REAL NOT NULL,
  recorded_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS email_notifications (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES profiles(id) ON DELETE CASCADE,
  user_uid TEXT,
  recipient_email TEXT NOT NULL,
  event_type TEXT NOT NULL,
  subject TEXT NOT NULL,
  provider TEXT NOT NULL,
  delivery_status TEXT NOT NULL,
  provider_message_id TEXT,
  error_message TEXT,
  sent_at TIMESTAMP NOT NULL DEFAULT NOW()
);
