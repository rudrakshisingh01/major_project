# InterviewIQ — Smart Interview Management and Performance Tracking System with Adaptive Assessment

A full-stack EdTech & recruitment preparation web application developed as a final-year B.Tech Computer Science Major Project. InterviewIQ combines a structured 65+ question bank, real-time **Adaptive Difficulty Assessment**, deterministic **Rule-Based Answer Evaluation**, longitudinal **Performance Analytics**, **PDF Report Export**, and **Transactional Email Notifications**.

---

## Architecture & Tech Stack

- **Frontend:** React 19, Vite, TypeScript, Tailwind CSS v4, Lucide Icons, Recharts, jsPDF
- **Backend:** Node.js, Express.js REST API (`server.ts`)
- **Database:** PostgreSQL (Cloud SQL) managed via Drizzle ORM (`src/db/schema.ts`)
- **Authentication:** Firebase Authentication (Google Sign-In + Email/Password + Password Reset) verified server-side via `firebase-admin`
- **Transactional Email:** Resend REST API / Nodemailer SMTP with PostgreSQL notification audit logs

---

## Core Research Modules

### 1. Smart Adaptive Interview Engine (`src/services/adaptiveEngine.ts`)
- Starts at the difficulty chosen by the candidate (`Beginner`, `Intermediate`, or `Advanced`).
- Evaluates each answer immediately upon submission:
  - **Score ≥ 80%**: Escalates next question difficulty (`Beginner → Intermediate → Advanced`).
  - **Score 40%–79%**: Maintains current difficulty level while diversifying topics.
  - **Score < 40%**: Steps down one tier (`Advanced → Intermediate → Beginner`) to reinforce fundamentals.
- Enforces non-repeating question selection per session and prioritizes role-relevant questions across Technical, HR, or Mixed (70% Technical / 30% HR) interviews.

### 2. Rule-Based Answer Evaluation Module (`src/services/evaluationEngine.ts`)
Designed behind an extensible `AnswerEvaluator` interface so an external NLP/LLM provider can be integrated in the future without altering controllers. Scores every answer out of **10 marks**:
1. **Keyword Relevance (0–4.0):** Exact and stemmed matching against rubric keywords.
2. **Conceptual Understanding (0–2.5):** Domain vocabulary overlap with the reference answer plus causal reasoning markers.
3. **Completeness & Depth (0–2.0):** Sentence structure and length calibrated to question difficulty.
4. **Relevance (0–1.5):** Detects empty, gibberish, or echoed question text and checks topical anchoring.

### 3. Longitudinal Analytics & Recommendations (`src/services/recommendationEngine.ts`)
- Aggregates `performance_records` per topic, category (Technical vs HR), and difficulty tier.
- Surfaces weak topics (`averageScore < 6.5` or `accuracy < 60%`), score trend deltas across attempts, suggested starting difficulty, and targeted practice questions.

### 4. Transactional Email Notifications (`src/services/emailService.ts`)
Dispatches structured HTML & plain-text emails for:
- **Successful Registration** (welcome onboarding email)
- **Password Reset Requests**
- **Interview Completion** (overall score, duration, strengths, and focus topics)

---

## Database Schema

Six relational tables in PostgreSQL (also documented in `database_schema.sql`):
1. `profiles` — Student account profile & notification preferences (`uid` linked to Firebase Auth)
2. `questions` — Seeded 65+ Technical & HR questions across 12 topics + custom user-created questions
3. `interviews` — Session configuration, adaptive difficulty history, total scores, and completion state
4. `interview_answers` — Draft auto-saves, submitted responses, 4-part score breakdowns, and feedback
5. `performance_records` — Per-interview, per-topic accuracy and timing metrics
6. `email_notifications` — Delivery audit logs for transactional alerts

---

## Setup & Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure environment variables:**
   Copy `.env.example` and configure your PostgreSQL (`SQL_HOST`, `SQL_USER`, `SQL_PASSWORD`, `SQL_DB_NAME`, `SQL_ADMIN_USER`, `SQL_ADMIN_PASSWORD`) and optional transactional email credentials (`RESEND_API_KEY` or `SMTP_HOST` / `SMTP_USER` / `SMTP_PASS` + `EMAIL_FROM`).

3. **Push Drizzle schema to PostgreSQL:**
   ```bash
   npx drizzle-kit push --config=src/db/drizzle.config.ts
   ```

4. **Run in development mode:**
   ```bash
   npm run dev
   ```

5. **Build for production:**
   ```bash
   npm run build
   npm start
   ```
