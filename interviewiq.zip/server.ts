import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { and, desc, eq, ilike, or } from 'drizzle-orm';
import { createServer as createViteServer } from 'vite';

import { db } from './src/db/index.ts';
import {
  emailNotifications,
  interviewAnswers,
  interviews,
  performanceRecords,
  profiles,
  questions,
} from './src/db/schema.ts';
import { ensureQuestionsSeeded } from './src/db/seedQuestions.ts';
import { getOrCreateProfile, updateProfileByUid } from './src/db/users.ts';
import { adminAuth } from './src/lib/firebase-admin.ts';
import { AuthRequest, requireAuth } from './src/middleware/auth.ts';
import {
  computeNextDifficulty,
  normalizeDifficulty,
  selectNextAdaptiveQuestion,
} from './src/services/adaptiveEngine.ts';
import {
  sendInterviewCompletionEmail,
  sendPasswordResetNotificationEmail,
  sendRegistrationEmail,
} from './src/services/emailService.ts';
import { answerEvaluator } from './src/services/evaluationEngine.ts';
import { generatePersonalizedRecommendations } from './src/services/recommendationEngine.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json({ limit: '1mb' }));

// Health endpoint
app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'InterviewIQ API' });
});

// Downloadable source archive (excludes node_modules, dist, and .env)
const sendSourceZip = (_req: express.Request, res: express.Response) => {
  const zipPath = path.resolve(__dirname, 'exports', 'InterviewIQ-Source.zip');
  if (!fs.existsSync(zipPath)) {
    return res.status(404).json({ error: 'Source archive not found.' });
  }
  const buffer = fs.readFileSync(zipPath);
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="InterviewIQ-Source.zip"');
  res.setHeader('Content-Length', String(buffer.length));
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  return res.status(200).send(buffer);
};

app.get('/api/export-source', sendSourceZip);
app.get('/InterviewIQ-Source.zip', sendSourceZip);

// Public endpoint to log and dispatch transactional password reset notification
app.post('/api/auth/password-reset-alert', async (req, res) => {
  try {
    const email = typeof req.body?.email === 'string' ? req.body.email.trim() : '';
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: 'Please provide a valid email address.' });
    }

    let resetLink: string | undefined;
    try {
      resetLink = await adminAuth.generatePasswordResetLink(email);
    } catch {
      // User may not exist or email/password provider not enabled; still send safe transactional notification
      resetLink = undefined;
    }

    const result = await sendPasswordResetNotificationEmail({ email, resetLink });
    res.json({
      success: true,
      deliveryStatus: result.deliveryStatus,
      provider: result.provider,
    });
  } catch (error: any) {
    console.error('Password reset alert error:', error);
    res.status(500).json({ error: 'Unable to process password reset notification.' });
  }
});

// Profile sync & registration welcome email trigger
app.get('/api/profile', requireAuth, async (req: AuthRequest, res) => {
  try {
    await ensureQuestionsSeeded();
    const uid = req.user!.uid;
    const email = req.user!.email || `${uid}@student.local`;
    const nameFromToken = req.user!.name as string | undefined;

    const existing = await db
      .select()
      .from(profiles)
      .where(eq(profiles.uid, uid))
      .limit(1);

    const isNewUser = existing.length === 0;
    const profile = await getOrCreateProfile(uid, email, nameFromToken);

    if (isNewUser && profile.emailAlertsEnabled) {
      // Fire transactional welcome email asynchronously without blocking login response
      sendRegistrationEmail({
        userId: profile.id,
        userUid: profile.uid,
        email: profile.email,
        fullName: profile.fullName,
      }).catch((err) => console.error('Registration email dispatch error:', err));
    }

    res.json({ profile, isNewUser });
  } catch (error: any) {
    console.error('GET /api/profile error:', error);
    res.status(500).json({ error: error.message || 'Failed to load profile' });
  }
});

app.put('/api/profile', requireAuth, async (req: AuthRequest, res) => {
  try {
    const uid = req.user!.uid;
    const email = req.user!.email || `${uid}@student.local`;
    await getOrCreateProfile(uid, email, req.user!.name as string | undefined);

    const {
      fullName,
      targetRole,
      collegeName,
      graduationYear,
      experienceLevel,
      bio,
      emailAlertsEnabled,
    } = req.body ?? {};

    if (typeof fullName === 'string' && fullName.trim().length < 2) {
      return res.status(400).json({ error: 'Full name must be at least 2 characters.' });
    }

    const updated = await db
      .update(profiles)
      .set({
        ...(typeof fullName === 'string' ? { fullName: fullName.trim() } : {}),
        ...(typeof targetRole === 'string' ? { targetRole } : {}),
        ...(typeof collegeName === 'string' ? { collegeName: collegeName.trim() } : {}),
        ...(typeof graduationYear === 'string' ? { graduationYear: graduationYear.trim() } : {}),
        ...(typeof experienceLevel === 'string' ? { experienceLevel } : {}),
        ...(typeof bio === 'string' ? { bio: bio.trim() } : {}),
        ...(typeof emailAlertsEnabled === 'boolean' ? { emailAlertsEnabled } : {}),
        updatedAt: new Date(),
      })
      .where(eq(profiles.uid, uid))
      .returning();

    res.json({ profile: updated[0] });
  } catch (error: any) {
    console.error('PUT /api/profile error:', error);
    res.status(500).json({ error: error.message || 'Failed to update profile' });
  }
});

// Transactional email notification log for user profile
app.get('/api/notifications', requireAuth, async (req: AuthRequest, res) => {
  try {
    const uid = req.user!.uid;
    const email = req.user!.email || '';
    const logs = await db
      .select()
      .from(emailNotifications)
      .where(
        or(
          eq(emailNotifications.userUid, uid),
          eq(emailNotifications.recipientEmail, email)
        )
      )
      .orderBy(desc(emailNotifications.sentAt))
      .limit(20);

    res.json({ notifications: logs });
  } catch (error: any) {
    console.error('GET /api/notifications error:', error);
    res.status(500).json({ error: 'Failed to load email notification logs.' });
  }
});

// ================= QUESTION BANK CRUD =================
app.get('/api/questions', requireAuth, async (req: AuthRequest, res) => {
  try {
    await ensureQuestionsSeeded();
    const { search, topic, role, category, difficulty } = req.query;

    const conditions = [];
    if (typeof topic === 'string' && topic && topic !== 'All') {
      conditions.push(eq(questions.topic, topic));
    }
    if (typeof category === 'string' && category && category !== 'All') {
      conditions.push(eq(questions.category, category));
    }
    if (typeof difficulty === 'string' && difficulty && difficulty !== 'All') {
      conditions.push(eq(questions.difficulty, difficulty));
    }
    if (typeof search === 'string' && search.trim()) {
      const pattern = `%${search.trim()}%`;
      conditions.push(
        or(
          ilike(questions.questionText, pattern),
          ilike(questions.topic, pattern),
          ilike(questions.questionCode, pattern)
        )
      );
    }

    const rows =
      conditions.length > 0
        ? await db
            .select()
            .from(questions)
            .where(and(...conditions))
            .orderBy(questions.id)
        : await db.select().from(questions).orderBy(questions.id);

    const filteredByRole =
      typeof role === 'string' && role && role !== 'All'
        ? rows.filter(
            (q) =>
              q.jobRole === role ||
              (Array.isArray(q.applicableRoles) && q.applicableRoles.includes(role))
          )
        : rows;

    res.json({ questions: filteredByRole });
  } catch (error: any) {
    console.error('GET /api/questions error:', error);
    res.status(500).json({ error: 'Failed to load question bank.' });
  }
});

app.post('/api/questions', requireAuth, async (req: AuthRequest, res) => {
  try {
    await ensureQuestionsSeeded();
    const uid = req.user!.uid;
    const {
      questionText,
      topic,
      jobRole,
      category,
      difficulty,
      expectedAnswer,
      evaluationKeywords,
      evaluationCriteria,
      marks,
    } = req.body ?? {};

    if (!questionText || !topic || !jobRole || !category || !difficulty || !expectedAnswer) {
      return res.status(400).json({ error: 'All required question fields must be filled.' });
    }

    const keywordsArray = Array.isArray(evaluationKeywords)
      ? evaluationKeywords.map((k: string) => String(k).trim()).filter(Boolean)
      : String(evaluationKeywords || '')
          .split(',')
          .map((k) => k.trim())
          .filter(Boolean);

    if (keywordsArray.length < 2) {
      return res
        .status(400)
        .json({ error: 'Please provide at least 2 evaluation keywords.' });
    }

    const code = `IQ-USR-${Date.now().toString().slice(-6)}`;
    const inserted = await db
      .insert(questions)
      .values({
        questionCode: code,
        questionText: String(questionText).trim(),
        topic: String(topic).trim(),
        jobRole: String(jobRole).trim(),
        applicableRoles: [String(jobRole).trim()],
        category: String(category),
        difficulty: normalizeDifficulty(String(difficulty)),
        expectedAnswer: String(expectedAnswer).trim(),
        evaluationKeywords: keywordsArray,
        evaluationCriteria:
          String(evaluationCriteria || '').trim() ||
          'Evaluate accuracy, depth, and coverage of required concepts.',
        marks: Number(marks) || 10,
        createdByUid: uid,
      })
      .returning();

    res.status(201).json({ question: inserted[0] });
  } catch (error: any) {
    console.error('POST /api/questions error:', error);
    res.status(500).json({ error: 'Failed to create question.' });
  }
});

app.put('/api/questions/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      return res.status(400).json({ error: 'Invalid question ID.' });
    }

    const existing = await db.select().from(questions).where(eq(questions.id, id)).limit(1);
    if (existing.length === 0) {
      return res.status(404).json({ error: 'Question not found.' });
    }
    if (existing[0].createdByUid !== req.user!.uid) {
      return res
        .status(403)
        .json({ error: 'You can only edit custom questions you created.' });
    }

    const {
      questionText,
      topic,
      jobRole,
      category,
      difficulty,
      expectedAnswer,
      evaluationKeywords,
      evaluationCriteria,
    } = req.body ?? {};

    const keywordsArray = Array.isArray(evaluationKeywords)
      ? evaluationKeywords.map((k: string) => String(k).trim()).filter(Boolean)
      : typeof evaluationKeywords === 'string'
      ? evaluationKeywords
          .split(',')
          .map((k) => k.trim())
          .filter(Boolean)
      : existing[0].evaluationKeywords;

    const updated = await db
      .update(questions)
      .set({
        ...(questionText ? { questionText: String(questionText).trim() } : {}),
        ...(topic ? { topic: String(topic) } : {}),
        ...(jobRole ? { jobRole: String(jobRole), applicableRoles: [String(jobRole)] } : {}),
        ...(category ? { category: String(category) } : {}),
        ...(difficulty ? { difficulty: normalizeDifficulty(String(difficulty)) } : {}),
        ...(expectedAnswer ? { expectedAnswer: String(expectedAnswer).trim() } : {}),
        evaluationKeywords: keywordsArray,
        ...(evaluationCriteria ? { evaluationCriteria: String(evaluationCriteria).trim() } : {}),
      })
      .where(eq(questions.id, id))
      .returning();

    res.json({ question: updated[0] });
  } catch (error: any) {
    console.error('PUT /api/questions/:id error:', error);
    res.status(500).json({ error: 'Failed to update question.' });
  }
});

app.delete('/api/questions/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      return res.status(400).json({ error: 'Invalid question ID.' });
    }

    const existing = await db.select().from(questions).where(eq(questions.id, id)).limit(1);
    if (existing.length === 0) {
      return res.status(404).json({ error: 'Question not found.' });
    }
    if (existing[0].createdByUid !== req.user!.uid) {
      return res
        .status(403)
        .json({ error: 'System seed questions cannot be deleted. You can delete custom questions you created.' });
    }

    await db.delete(questions).where(eq(questions.id, id));
    res.json({ success: true });
  } catch (error: any) {
    console.error('DELETE /api/questions/:id error:', error);
    res.status(500).json({ error: 'Failed to delete question.' });
  }
});

// ================= INTERVIEW ENGINE ROUTES =================
app.post('/api/interviews/start', requireAuth, async (req: AuthRequest, res) => {
  try {
    await ensureQuestionsSeeded();
    const uid = req.user!.uid;
    const email = req.user!.email || `${uid}@student.local`;
    const profile = await getOrCreateProfile(uid, email, req.user!.name as string | undefined);

    const { jobRole, category, difficulty, totalQuestions, timeLimitMinutes } = req.body ?? {};
    const validCounts = [5, 10, 15, 20];
    const qCount = validCounts.includes(Number(totalQuestions)) ? Number(totalQuestions) : 5;
    const initialDiff = normalizeDifficulty(String(difficulty || 'Beginner'));
    const roleStr = String(jobRole || 'Software Engineer');
    const catStr = String(category || 'Technical Interview');
    const timeLimit = Math.max(5, Math.min(120, Number(timeLimitMinutes) || qCount * 3));

    const allQuestions = await db.select().from(questions);
    const firstQuestion = selectNextAdaptiveQuestion({
      allQuestions,
      usedQuestionIds: new Set<number>(),
      coveredTopics: {},
      targetDifficulty: initialDiff,
      jobRole: roleStr,
      interviewCategory: catStr,
      questionOrder: 1,
      totalQuestions: qCount,
    });

    if (!firstQuestion) {
      return res.status(400).json({ error: 'No questions available in question bank.' });
    }

    const created = await db
      .insert(interviews)
      .values({
        userId: profile.id,
        userUid: uid,
        jobRole: roleStr,
        category: catStr,
        initialDifficulty: initialDiff,
        currentDifficulty: initialDiff,
        totalQuestions: qCount,
        answeredCount: 0,
        timeLimitMinutes: timeLimit,
        status: 'in_progress',
        maxScore: qCount * 10,
        adaptiveHistory: [
          {
            step: 1,
            difficulty: initialDiff,
            scorePercent: null,
            action: 'initial',
            message: `Starting interview at ${initialDiff} difficulty as configured.`,
          },
        ],
      })
      .returning();

    const interview = created[0];

    const firstSlot = await db
      .insert(interviewAnswers)
      .values({
        interviewId: interview.id,
        questionId: firstQuestion.id,
        userUid: uid,
        questionOrder: 1,
        difficultyAtTime: initialDiff,
        maxMarks: firstQuestion.marks,
        isSubmitted: false,
        nextDifficulty: initialDiff,
      })
      .returning();

    res.status(201).json({
      interview,
      currentSlot: firstSlot[0],
      currentQuestion: firstQuestion,
    });
  } catch (error: any) {
    console.error('POST /api/interviews/start error:', error);
    res.status(500).json({ error: 'Failed to start adaptive interview session.' });
  }
});

app.get('/api/interviews', requireAuth, async (req: AuthRequest, res) => {
  try {
    const uid = req.user!.uid;
    const rows = await db
      .select()
      .from(interviews)
      .where(eq(interviews.userUid, uid))
      .orderBy(desc(interviews.startedAt));

    res.json({ interviews: rows });
  } catch (error: any) {
    console.error('GET /api/interviews error:', error);
    res.status(500).json({ error: 'Failed to load interview history.' });
  }
});

app.get('/api/interviews/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const interviewId = Number(req.params.id);
    if (!Number.isFinite(interviewId)) {
      return res.status(400).json({ error: 'Invalid interview ID.' });
    }

    const found = await db
      .select()
      .from(interviews)
      .where(and(eq(interviews.id, interviewId), eq(interviews.userUid, req.user!.uid)))
      .limit(1);

    if (found.length === 0) {
      return res.status(404).json({ error: 'Interview not found.' });
    }

    const answerRows = await db
      .select({
        answer: interviewAnswers,
        question: questions,
      })
      .from(interviewAnswers)
      .innerJoin(questions, eq(interviewAnswers.questionId, questions.id))
      .where(eq(interviewAnswers.interviewId, interviewId))
      .orderBy(interviewAnswers.questionOrder);

    res.json({
      interview: found[0],
      items: answerRows.map((r) => ({
        ...r.answer,
        question: r.question,
      })),
    });
  } catch (error: any) {
    console.error('GET /api/interviews/:id error:', error);
    res.status(500).json({ error: 'Failed to load interview details.' });
  }
});

// Auto-save draft answer
app.post('/api/interviews/:id/draft', requireAuth, async (req: AuthRequest, res) => {
  try {
    const interviewId = Number(req.params.id);
    const { answerSlotId, draftAnswer, timeSpentSeconds } = req.body ?? {};

    if (!Number.isFinite(interviewId) || !Number.isFinite(Number(answerSlotId))) {
      return res.status(400).json({ error: 'Invalid interview or slot identifier.' });
    }

    await db
      .update(interviewAnswers)
      .set({
        draftAnswer: String(draftAnswer ?? ''),
        ...(Number.isFinite(Number(timeSpentSeconds))
          ? { timeSpentSeconds: Math.max(0, Math.round(Number(timeSpentSeconds))) }
          : {}),
      })
      .where(
        and(
          eq(interviewAnswers.id, Number(answerSlotId)),
          eq(interviewAnswers.interviewId, interviewId),
          eq(interviewAnswers.userUid, req.user!.uid)
        )
      );

    res.json({ saved: true });
  } catch (error: any) {
    console.error('POST /api/interviews/:id/draft error:', error);
    res.status(500).json({ error: 'Failed to auto-save draft.' });
  }
});

// Evaluate submitted answer + compute next adaptive difficulty + select next non-repeating question
app.post('/api/interviews/:id/answer', requireAuth, async (req: AuthRequest, res) => {
  try {
    const interviewId = Number(req.params.id);
    const { answerSlotId, userAnswer, timeSpentSeconds } = req.body ?? {};
    const uid = req.user!.uid;

    const interviewRows = await db
      .select()
      .from(interviews)
      .where(and(eq(interviews.id, interviewId), eq(interviews.userUid, uid)))
      .limit(1);

    if (interviewRows.length === 0) {
      return res.status(404).json({ error: 'Interview session not found.' });
    }
    const interview = interviewRows[0];

    const slotRows = await db
      .select({
        slot: interviewAnswers,
        question: questions,
      })
      .from(interviewAnswers)
      .innerJoin(questions, eq(interviewAnswers.questionId, questions.id))
      .where(
        and(
          eq(interviewAnswers.id, Number(answerSlotId)),
          eq(interviewAnswers.interviewId, interviewId),
          eq(interviewAnswers.userUid, uid)
        )
      )
      .limit(1);

    if (slotRows.length === 0) {
      return res.status(404).json({ error: 'Question slot not found.' });
    }

    const { slot, question } = slotRows[0];

    // Run Rule-Based Answer Evaluation
    const evaluation = await answerEvaluator.evaluate({
      questionText: question.questionText,
      topic: question.topic,
      difficulty: slot.difficultyAtTime,
      expectedAnswer: question.expectedAnswer,
      evaluationKeywords: question.evaluationKeywords,
      evaluationCriteria: question.evaluationCriteria,
      userAnswer: String(userAnswer ?? ''),
      maxMarks: slot.maxMarks,
    });

    // Compute Adaptive Next Difficulty
    const adaptive = computeNextDifficulty(slot.difficultyAtTime, evaluation.percentage);

    const updatedSlot = await db
      .update(interviewAnswers)
      .set({
        userAnswer: String(userAnswer ?? '').trim(),
        draftAnswer: String(userAnswer ?? ''),
        score: evaluation.score,
        isSubmitted: true,
        correctnessLevel: evaluation.correctnessLevel,
        feedback: evaluation.feedback,
        matchedKeywords: evaluation.matchedKeywords,
        missingConcepts: evaluation.missingConcepts,
        suggestedImprovements: evaluation.suggestedImprovements,
        scoreBreakdown: evaluation.scoreBreakdown,
        adaptiveMessage: adaptive.message,
        nextDifficulty: adaptive.nextDifficulty,
        timeSpentSeconds: Math.max(1, Math.round(Number(timeSpentSeconds) || 15)),
        answeredAt: new Date(),
      })
      .where(eq(interviewAnswers.id, slot.id))
      .returning();

    // Recompute existing answers in this interview
    const allSlots = await db
      .select({
        slot: interviewAnswers,
        question: questions,
      })
      .from(interviewAnswers)
      .innerJoin(questions, eq(interviewAnswers.questionId, questions.id))
      .where(eq(interviewAnswers.interviewId, interviewId))
      .orderBy(interviewAnswers.questionOrder);

    const submittedSlots = allSlots.filter((s) => s.slot.isSubmitted);
    const totalScore = Number(
      submittedSlots.reduce((sum, s) => sum + s.slot.score, 0).toFixed(1)
    );
    const maxScoreSoFar = interview.totalQuestions * 10;
    const pct = Number(((totalScore / maxScoreSoFar) * 100).toFixed(1));

    const updatedHistory = [
      ...(Array.isArray(interview.adaptiveHistory) ? interview.adaptiveHistory : []),
      {
        step: slot.questionOrder,
        difficulty: slot.difficultyAtTime,
        scorePercent: evaluation.percentage,
        action: adaptive.action,
        message: adaptive.message,
      },
    ];

    // Check if we need to generate the next adaptive question slot
    let nextSlot: typeof interviewAnswers.$inferSelect | null = null;
    let nextQuestion: typeof questions.$inferSelect | null = null;

    const alreadyHasNext = allSlots.find(
      (s) => s.slot.questionOrder === slot.questionOrder + 1
    );

    if (alreadyHasNext) {
      nextSlot = alreadyHasNext.slot;
      nextQuestion = alreadyHasNext.question;
    } else if (slot.questionOrder < interview.totalQuestions) {
      const allBankQuestions = await db.select().from(questions);
      const usedIds = new Set(allSlots.map((s) => s.slot.questionId));
      const coveredTopics: Record<string, number> = {};
      for (const s of allSlots) {
        coveredTopics[s.question.topic] = (coveredTopics[s.question.topic] ?? 0) + 1;
      }

      nextQuestion = selectNextAdaptiveQuestion({
        allQuestions: allBankQuestions,
        usedQuestionIds: usedIds,
        coveredTopics,
        targetDifficulty: adaptive.nextDifficulty,
        jobRole: interview.jobRole,
        interviewCategory: interview.category,
        questionOrder: slot.questionOrder + 1,
        totalQuestions: interview.totalQuestions,
      });

      if (nextQuestion) {
        const insertedNext = await db
          .insert(interviewAnswers)
          .values({
            interviewId: interview.id,
            questionId: nextQuestion.id,
            userUid: uid,
            questionOrder: slot.questionOrder + 1,
            difficultyAtTime: adaptive.nextDifficulty,
            maxMarks: nextQuestion.marks,
            isSubmitted: false,
            nextDifficulty: adaptive.nextDifficulty,
          })
          .returning();
        nextSlot = insertedNext[0];
      }
    }

    const updatedInterview = await db
      .update(interviews)
      .set({
        currentDifficulty: adaptive.nextDifficulty,
        answeredCount: submittedSlots.length,
        totalScore,
        percentage: pct,
        adaptiveHistory: updatedHistory,
      })
      .where(eq(interviews.id, interviewId))
      .returning();

    res.json({
      evaluatedSlot: updatedSlot[0],
      evaluation,
      adaptiveDecision: adaptive,
      interview: updatedInterview[0],
      nextSlot,
      nextQuestion,
      isLastQuestion: slot.questionOrder >= interview.totalQuestions,
    });
  } catch (error: any) {
    console.error('POST /api/interviews/:id/answer error:', error);
    res.status(500).json({ error: 'Failed to evaluate answer.' });
  }
});

// Complete interview, generate performance_records, and send transactional summary email
app.post('/api/interviews/:id/complete', requireAuth, async (req: AuthRequest, res) => {
  try {
    const interviewId = Number(req.params.id);
    const uid = req.user!.uid;
    const totalDurationSeconds = Math.max(10, Math.round(Number(req.body?.durationSeconds) || 60));

    const interviewRows = await db
      .select()
      .from(interviews)
      .where(and(eq(interviews.id, interviewId), eq(interviews.userUid, uid)))
      .limit(1);

    if (interviewRows.length === 0) {
      return res.status(404).json({ error: 'Interview not found.' });
    }
    const interview = interviewRows[0];

    const slotRows = await db
      .select({
        slot: interviewAnswers,
        question: questions,
      })
      .from(interviewAnswers)
      .innerJoin(questions, eq(interviewAnswers.questionId, questions.id))
      .where(eq(interviewAnswers.interviewId, interviewId))
      .orderBy(interviewAnswers.questionOrder);

    // If any loaded slot has an unsubmitted draft, auto-evaluate it on final submission
    for (const row of slotRows) {
      if (!row.slot.isSubmitted) {
        const answerText = (row.slot.draftAnswer || row.slot.userAnswer || '').trim();
        const evaluation = await answerEvaluator.evaluate({
          questionText: row.question.questionText,
          topic: row.question.topic,
          difficulty: row.slot.difficultyAtTime,
          expectedAnswer: row.question.expectedAnswer,
          evaluationKeywords: row.question.evaluationKeywords,
          evaluationCriteria: row.question.evaluationCriteria,
          userAnswer: answerText,
          maxMarks: row.slot.maxMarks,
        });

        await db
          .update(interviewAnswers)
          .set({
            userAnswer: answerText,
            score: evaluation.score,
            isSubmitted: true,
            correctnessLevel: evaluation.correctnessLevel,
            feedback: evaluation.feedback,
            matchedKeywords: evaluation.matchedKeywords,
            missingConcepts: evaluation.missingConcepts,
            suggestedImprovements: evaluation.suggestedImprovements,
            scoreBreakdown: evaluation.scoreBreakdown,
            answeredAt: new Date(),
          })
          .where(eq(interviewAnswers.id, row.slot.id));
      }
    }

    // Reload finalized answers
    const finalizedRows = await db
      .select({
        slot: interviewAnswers,
        question: questions,
      })
      .from(interviewAnswers)
      .innerJoin(questions, eq(interviewAnswers.questionId, questions.id))
      .where(eq(interviewAnswers.interviewId, interviewId))
      .orderBy(interviewAnswers.questionOrder);

    const totalScore = Number(
      finalizedRows.reduce((sum, r) => sum + r.slot.score, 0).toFixed(1)
    );
    const maxScore = Math.max(finalizedRows.length * 10, interview.totalQuestions * 10);
    const percentage = Number(((totalScore / maxScore) * 100).toFixed(1));

    const completedRows = await db
      .update(interviews)
      .set({
        status: 'completed',
        answeredCount: finalizedRows.length,
        totalScore,
        maxScore,
        percentage,
        durationSeconds: totalDurationSeconds,
        completedAt: new Date(),
      })
      .where(eq(interviews.id, interviewId))
      .returning();

    // Clear old performance records for this interview if re-completed, then write fresh topic breakdown
    await db
      .delete(performanceRecords)
      .where(eq(performanceRecords.interviewId, interviewId));

    const topicGroups = new Map<
      string,
      {
        category: string;
        difficulty: string;
        scores: number[];
        correct: number;
        times: number[];
      }
    >();

    for (const r of finalizedRows) {
      const key = r.question.topic;
      const grp = topicGroups.get(key) ?? {
        category: r.question.category,
        difficulty: r.slot.difficultyAtTime,
        scores: [],
        correct: 0,
        times: [],
      };
      grp.scores.push(r.slot.score);
      if (r.slot.score >= 6.0) grp.correct += 1;
      grp.times.push(r.slot.timeSpentSeconds || 30);
      topicGroups.set(key, grp);
    }

    const strengths: string[] = [];
    const weakTopics: string[] = [];
    const recordsToInsert = [];

    for (const [topic, grp] of topicGroups.entries()) {
      const avgScore = grp.scores.reduce((a, b) => a + b, 0) / grp.scores.length;
      const accuracy = (grp.correct / grp.scores.length) * 100;
      const avgTime = grp.times.reduce((a, b) => a + b, 0) / grp.times.length;

      if (avgScore >= 7.0) strengths.push(topic);
      else if (avgScore < 6.0) weakTopics.push(topic);

      recordsToInsert.push({
        userId: interview.userId,
        userUid: uid,
        interviewId,
        topic,
        category: grp.category,
        difficulty: grp.difficulty,
        questionsAttempted: grp.scores.length,
        correctCount: grp.correct,
        averageScore: Number(avgScore.toFixed(1)),
        accuracyPercentage: Number(accuracy.toFixed(1)),
        avgTimeSeconds: Number(avgTime.toFixed(1)),
      });
    }

    if (recordsToInsert.length > 0) {
      await db.insert(performanceRecords).values(recordsToInsert);
    }

    // Dispatch transactional interview completion summary email if enabled
    const profileRows = await db
      .select()
      .from(profiles)
      .where(eq(profiles.uid, uid))
      .limit(1);

    let emailDispatchStatus: string | null = null;
    if (profileRows.length > 0 && profileRows[0].emailAlertsEnabled) {
      const emailResult = await sendInterviewCompletionEmail({
        userId: profileRows[0].id,
        userUid: uid,
        email: profileRows[0].email,
        fullName: profileRows[0].fullName,
        interviewId,
        jobRole: interview.jobRole,
        category: interview.category,
        totalScore,
        maxScore,
        percentage,
        durationSeconds: totalDurationSeconds,
        strengths,
        weakTopics,
      });
      emailDispatchStatus = emailResult.deliveryStatus;
    }

    res.json({
      interview: completedRows[0],
      emailDispatchStatus,
    });
  } catch (error: any) {
    console.error('POST /api/interviews/:id/complete error:', error);
    res.status(500).json({ error: 'Failed to finalize interview report.' });
  }
});

app.delete('/api/interviews/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      return res.status(400).json({ error: 'Invalid interview ID.' });
    }
    await db
      .delete(interviews)
      .where(and(eq(interviews.id, id), eq(interviews.userUid, req.user!.uid)));
    res.json({ success: true });
  } catch (error: any) {
    console.error('DELETE /api/interviews/:id error:', error);
    res.status(500).json({ error: 'Failed to delete interview.' });
  }
});

// ================= DASHBOARD, ANALYTICS & RECOMMENDATIONS =================
app.get('/api/dashboard', requireAuth, async (req: AuthRequest, res) => {
  try {
    await ensureQuestionsSeeded();
    const uid = req.user!.uid;
    const email = req.user!.email || `${uid}@student.local`;
    const profile = await getOrCreateProfile(uid, email, req.user!.name as string | undefined);

    const userInterviews = await db
      .select()
      .from(interviews)
      .where(eq(interviews.userUid, uid))
      .orderBy(desc(interviews.startedAt));

    const completed = userInterviews.filter((i) => i.status === 'completed');
    const totalInterviews = completed.length;
    const avgScore =
      totalInterviews > 0
        ? Number(
            (completed.reduce((s, i) => s + i.percentage, 0) / totalInterviews).toFixed(1)
          )
        : 0;
    const bestScore =
      totalInterviews > 0
        ? Number(Math.max(...completed.map((i) => i.percentage)).toFixed(1))
        : 0;

    const userAnswers = await db
      .select()
      .from(interviewAnswers)
      .where(
        and(eq(interviewAnswers.userUid, uid), eq(interviewAnswers.isSubmitted, true))
      );

    const totalQuestionsAnswered = userAnswers.length;

    let performanceLevel = 'Starter';
    if (totalInterviews > 0) {
      if (avgScore >= 82) performanceLevel = 'Placement Ready';
      else if (avgScore >= 65) performanceLevel = 'Proficient';
      else if (avgScore >= 45) performanceLevel = 'Developing';
      else performanceLevel = 'Foundational';
    }

    const records = await db
      .select()
      .from(performanceRecords)
      .where(eq(performanceRecords.userUid, uid));

    const topicAgg = new Map<string, { scoreSum: number; count: number; correct: number }>();
    for (const r of records) {
      const cur = topicAgg.get(r.topic) ?? { scoreSum: 0, count: 0, correct: 0 };
      cur.scoreSum += r.averageScore * r.questionsAttempted;
      cur.count += r.questionsAttempted;
      cur.correct += r.correctCount;
      topicAgg.set(r.topic, cur);
    }

    const topicBreakdown = Array.from(topicAgg.entries()).map(([topic, d]) => ({
      topic,
      averageScore: Number((d.scoreSum / Math.max(1, d.count)).toFixed(1)),
      accuracy: Number(((d.correct / Math.max(1, d.count)) * 100).toFixed(1)),
      questionsAttempted: d.count,
    }));

    const strengths = topicBreakdown
      .filter((t) => t.averageScore >= 7.0)
      .sort((a, b) => b.averageScore - a.averageScore);
    const weaknesses = topicBreakdown
      .filter((t) => t.averageScore < 6.5)
      .sort((a, b) => a.averageScore - b.averageScore);

    // Weekly performance (last 7 sessions or grouped by day)
    const weeklyChart = completed
      .slice(0, 7)
      .reverse()
      .map((item, idx) => ({
        label: new Date(item.completedAt || item.startedAt).toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
        }),
        session: `Attempt ${idx + 1}`,
        score: item.percentage,
        role: item.jobRole,
      }));

    const recommendations = await generatePersonalizedRecommendations(uid, profile.targetRole);

    res.json({
      profile,
      summary: {
        totalInterviews,
        averageScore: avgScore,
        bestScore,
        totalQuestionsAnswered,
        performanceLevel,
      },
      recentInterviews: userInterviews.slice(0, 5),
      weeklyChart,
      topicBreakdown,
      strengths,
      weaknesses,
      recommendations,
    });
  } catch (error: any) {
    console.error('GET /api/dashboard error:', error);
    res.status(500).json({ error: 'Failed to load dashboard metrics.' });
  }
});

app.get('/api/analytics', requireAuth, async (req: AuthRequest, res) => {
  try {
    const uid = req.user!.uid;
    const email = req.user!.email || `${uid}@student.local`;
    const profile = await getOrCreateProfile(uid, email, req.user!.name as string | undefined);

    const completed = await db
      .select()
      .from(interviews)
      .where(and(eq(interviews.userUid, uid), eq(interviews.status, 'completed')))
      .orderBy(interviews.completedAt);

    const records = await db
      .select()
      .from(performanceRecords)
      .where(eq(performanceRecords.userUid, uid));

    const answers = await db
      .select({
        answer: interviewAnswers,
        question: questions,
      })
      .from(interviewAnswers)
      .innerJoin(questions, eq(interviewAnswers.questionId, questions.id))
      .where(
        and(eq(interviewAnswers.userUid, uid), eq(interviewAnswers.isSubmitted, true))
      );

    // 1. Score over time & interview comparison
    const scoreTimeline = completed.map((i, idx) => ({
      attempt: `#${idx + 1}`,
      date: new Date(i.completedAt || i.startedAt).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
      }),
      percentage: i.percentage,
      totalScore: i.totalScore,
      role: i.jobRole,
      category: i.category,
      durationMinutes: Number((i.durationSeconds / 60).toFixed(1)),
    }));

    // 2. Topic-wise performance
    const topicMap = new Map<
      string,
      { scoreSum: number; count: number; correct: number; timeSum: number }
    >();
    for (const r of records) {
      const cur = topicMap.get(r.topic) ?? { scoreSum: 0, count: 0, correct: 0, timeSum: 0 };
      cur.scoreSum += r.averageScore * r.questionsAttempted;
      cur.count += r.questionsAttempted;
      cur.correct += r.correctCount;
      cur.timeSum += r.avgTimeSeconds * r.questionsAttempted;
      topicMap.set(r.topic, cur);
    }

    const topicPerformance = Array.from(topicMap.entries()).map(([topic, d]) => ({
      topic,
      averageScore: Number((d.scoreSum / Math.max(1, d.count)).toFixed(1)),
      accuracy: Number(((d.correct / Math.max(1, d.count)) * 100).toFixed(1)),
      avgTimeSeconds: Number((d.timeSum / Math.max(1, d.count)).toFixed(0)),
      attempts: d.count,
    }));

    // 3. Technical vs HR comparison
    const catMap = new Map<string, { scoreSum: number; count: number; correct: number }>();
    for (const a of answers) {
      const cat = a.question.category;
      const cur = catMap.get(cat) ?? { scoreSum: 0, count: 0, correct: 0 };
      cur.scoreSum += a.answer.score;
      cur.count += 1;
      if (a.answer.score >= 6) cur.correct += 1;
      catMap.set(cat, cur);
    }

    const categoryComparison = Array.from(catMap.entries()).map(([category, d]) => ({
      category: category.replace(' Interview', ''),
      avgPercentage: Number(((d.scoreSum / Math.max(1, d.count * 10)) * 100).toFixed(1)),
      accuracy: Number(((d.correct / Math.max(1, d.count)) * 100).toFixed(1)),
      questions: d.count,
    }));

    // 4. Difficulty-wise performance
    const diffOrder = ['Beginner', 'Intermediate', 'Advanced'];
    const difficultyBreakdown = diffOrder.map((diff) => {
      const matching = answers.filter((a) => a.answer.difficultyAtTime === diff);
      const count = matching.length;
      const avgPct =
        count > 0
          ? Number(
              (
                (matching.reduce((s, m) => s + m.answer.score, 0) / (count * 10)) *
                100
              ).toFixed(1)
            )
          : 0;
      const avgTime =
        count > 0
          ? Number(
              (
                matching.reduce((s, m) => s + (m.answer.timeSpentSeconds || 0), 0) / count
              ).toFixed(0)
            )
          : 0;
      return {
        difficulty: diff,
        avgPercentage: avgPct,
        avgTimeSeconds: avgTime,
        questionsAttempted: count,
      };
    });

    const totalCorrect = answers.filter((a) => a.answer.score >= 6.0).length;
    const overallAccuracy =
      answers.length > 0 ? Number(((totalCorrect / answers.length) * 100).toFixed(1)) : 0;
    const avgTimePerQuestion =
      answers.length > 0
        ? Number(
            (
              answers.reduce((s, a) => s + (a.answer.timeSpentSeconds || 0), 0) /
              answers.length
            ).toFixed(0)
          )
        : 0;

    const recommendations = await generatePersonalizedRecommendations(uid, profile.targetRole);

    res.json({
      overview: {
        totalInterviews: completed.length,
        totalQuestionsAnswered: answers.length,
        overallAccuracy,
        avgTimePerQuestion,
      },
      scoreTimeline,
      topicPerformance,
      categoryComparison,
      difficultyBreakdown,
      recommendations,
    });
  } catch (error: any) {
    console.error('GET /api/analytics error:', error);
    res.status(500).json({ error: 'Failed to load analytics.' });
  }
});

app.get('/api/recommendations', requireAuth, async (req: AuthRequest, res) => {
  try {
    const uid = req.user!.uid;
    const email = req.user!.email || `${uid}@student.local`;
    const profile = await getOrCreateProfile(uid, email, req.user!.name as string | undefined);
    const recommendations = await generatePersonalizedRecommendations(uid, profile.targetRole);
    res.json({ recommendations });
  } catch (error: any) {
    console.error('GET /api/recommendations error:', error);
    res.status(500).json({ error: 'Failed to generate recommendations.' });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`InterviewIQ server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
