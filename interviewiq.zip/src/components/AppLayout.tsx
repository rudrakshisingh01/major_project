import React, { useState } from 'react';
import {
  BarChart3,
  BookOpen,
  Compass,
  History,
  LayoutDashboard,
  LogOut,
  Menu,
  PlayCircle,
  UserCircle2,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export type AppRoute =
  | 'dashboard'
  | 'setup'
  | 'live'
  | 'report'
  | 'questions'
  | 'analytics'
  | 'recommendations'
  | 'history'
  | 'profile';

interface AppLayoutProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
  pageTitle: string;
  children: React.ReactNode;
}

const NAV_ITEMS: Array<{ id: AppRoute; label: string; icon: React.ComponentType<any> }> = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'setup', label: 'Start Interview', icon: PlayCircle },
  { id: 'questions', label: 'Question Bank', icon: BookOpen },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'recommendations', label: 'Recommendations', icon: Compass },
  { id: 'history', label: 'Interview History', icon: History },
  { id: 'profile', label: 'Profile & Alerts', icon: UserCircle2 },
];

export function AppLayout({
  currentRoute,
  onNavigate,
  pageTitle,
  children,
}: AppLayoutProps) {
  const { profile, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNavClick = (id: AppRoute) => {
    onNavigate(id);
    setMobileOpen(false);
  };

  const initials = (profile?.fullName || 'S')
    .split(' ')
    .map((p) => p[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-[#0F172A] text-white">
      <div className="h-16 px-6 flex items-center justify-between border-b border-slate-800">
        <button
          type="button"
          onClick={() => handleNavClick('dashboard')}
          className="font-display text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0 cursor-pointer"
        >
          InterviewIQ
        </button>
        <button
          type="button"
          onClick={() => setMobileOpen(false)}
          className="lg:hidden text-slate-400 hover:text-white p-1"
          aria-label="Close sidebar"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active =
            currentRoute === item.id ||
            (item.id === 'setup' && currentRoute === 'live') ||
            (item.id === 'history' && currentRoute === 'report');

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                active
                  ? 'bg-[#1D4ED8] text-white'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-3 px-2 py-2">
          <div className="w-9 h-9 rounded-lg bg-[#1D4ED8] text-white font-semibold text-xs flex items-center justify-center shrink-0">
            {initials}
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-medium text-white truncate">
              {profile?.fullName || 'Student'}
            </div>
            <div className="text-xs text-slate-400 truncate">
              {profile?.targetRole || 'Software Engineer'}
            </div>
          </div>
        </div>
        <button
          type="button"
          onClick={logout}
          className="mt-2 w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium text-slate-300 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4 shrink-0" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex">
      {/* Desktop Fixed Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 border-r border-slate-200 sticky top-0 h-screen">
        <SidebarContent />
      </aside>

      {/* Mobile Drawer Overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="relative z-50 w-64 max-w-[80vw] h-full shadow-xl">
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main Content Shell */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-20 h-16 bg-white border-b border-slate-200 px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 -ml-2 text-slate-600 hover:text-[#0F172A] rounded-lg hover:bg-slate-100"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="hidden sm:inline text-slate-400">InterviewIQ</span>
              <span className="hidden sm:inline text-slate-300">/</span>
              <h1 className="font-display text-base sm:text-lg font-semibold text-[#0F172A] truncate">
                {pageTitle}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {currentRoute !== 'live' && currentRoute !== 'setup' && (
              <button
                type="button"
                onClick={() => onNavigate('setup')}
                className="px-4 py-2 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                New Interview
              </button>
            )}
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
