import React, { useState } from 'react';
import { Loader2, Play, SlidersHorizontal } from 'lucide-react';
import {
  DIFFICULTY_LEVELS,
  INTERVIEW_CATEGORIES,
  JOB_ROLES,
  QUESTION_COUNTS,
} from '../lib/constants';
import { apiRequest } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

interface InterviewSetupViewProps {
  onInterviewStarted: (payload: {
    interview: any;
    currentSlot: any;
    currentQuestion: any;
  }) => void;
}

export function InterviewSetupView({ onInterviewStarted }: InterviewSetupViewProps) {
  const { profile } = useAuth();
  const { showToast } = useToast();

  const [jobRole, setJobRole] = useState<string>(profile?.targetRole || 'Software Engineer');
  const [category, setCategory] = useState<string>('Technical Interview');
  const [difficulty, setDifficulty] = useState<string>('Beginner');
  const [totalQuestions, setTotalQuestions] = useState<number>(5);
  const [timeLimitMinutes, setTimeLimitMinutes] = useState<number>(15);
  const [starting, setStarting] = useState(false);

  const handleQuestionCountChange = (count: number) => {
    setTotalQuestions(count);
    setTimeLimitMinutes(count * 3);
  };

  const handleStart = async (e: React.FormEvent) => {
    e.preventDefault();
    setStarting(true);
    try {
      const result = await apiRequest('/api/interviews/start', {
        method: 'POST',
        body: JSON.stringify({
          jobRole,
          category,
          difficulty,
          totalQuestions,
          timeLimitMinutes,
        }),
      });
      showToast('Adaptive interview session initialized.', 'success');
      onInterviewStarted(result);
    } catch (err: any) {
      showToast(err.message || 'Failed to start interview.', 'error');
    } finally {
      setStarting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
        <div className="flex items-start gap-4 pb-6 border-b border-slate-200">
          <div className="w-11 h-11 rounded-xl bg-[#1D4ED8]/10 text-[#1D4ED8] flex items-center justify-center shrink-0">
            <SlidersHorizontal className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-display text-xl font-bold text-[#0F172A]">
              Configure Adaptive Mock Interview
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Choose your role, interview track, starting difficulty, question count, and time
              limit. Difficulty adapts automatically after every submitted answer.
            </p>
          </div>
        </div>

        <form onSubmit={handleStart} className="mt-6 space-y-6">
          {/* Job Role */}
          <div>
            <label className="block text-sm font-semibold text-[#0F172A] mb-2">
              Target Job Role
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {JOB_ROLES.map((role) => (
                <button
                  key={role}
                  type="button"
                  onClick={() => setJobRole(role)}
                  className={`px-3 py-2.5 text-xs sm:text-sm font-medium rounded-lg border text-left transition-colors cursor-pointer ${
                    jobRole === role
                      ? 'bg-[#1D4ED8] text-white border-[#1D4ED8]'
                      : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {role}
                </button>
              ))}
            </div>
          </div>

          {/* Interview Category */}
          <div>
            <label className="block text-sm font-semibold text-[#0F172A] mb-2">
              Interview Category
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {INTERVIEW_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`p-4 rounded-xl border text-left transition-colors cursor-pointer ${
                    category === cat
                      ? 'bg-[#EFF6FF] border-[#1D4ED8] text-[#0F172A]'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="font-semibold text-sm">{cat}</div>
                  <div className="text-xs text-slate-500 mt-1">
                    {cat === 'Technical Interview'
                      ? 'Core CS, algorithms, and stack-specific questions'
                      : cat === 'HR Interview'
                      ? 'Behavioral STAR scenarios, teamwork, and ownership'
                      : 'Balanced mix of 70% Technical and 30% HR'}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Starting Difficulty & Question Count */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-[#0F172A] mb-2">
                Starting Difficulty Level
              </label>
              <div className="grid grid-cols-3 gap-2 p-1 bg-slate-100 rounded-lg">
                {DIFFICULTY_LEVELS.map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setDifficulty(level)}
                    className={`py-2 px-3 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                      difficulty === level
                        ? 'bg-white text-[#0F172A] shadow-sm'
                        : 'text-slate-600 hover:text-[#0F172A]'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
              <p className="text-xs text-slate-500 mt-2">
                Adapts live: ≥80% moves up, 40–79% maintains, &lt;40% steps down.
              </p>
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#0F172A] mb-2">
                Number of Questions
              </label>
              <div className="grid grid-cols-4 gap-2 p-1 bg-slate-100 rounded-lg">
                {QUESTION_COUNTS.map((cnt) => (
                  <button
                    key={cnt}
                    type="button"
                    onClick={() => handleQuestionCountChange(cnt)}
                    className={`py-2 px-3 text-xs font-mono font-semibold rounded-md transition-colors cursor-pointer tabular-nums ${
                      totalQuestions === cnt
                        ? 'bg-white text-[#0F172A] shadow-sm'
                        : 'text-slate-600 hover:text-[#0F172A]'
                    }`}
                  >
                    {cnt}
                  </button>
                ))}
              </div>
              <p className="text-xs text-slate-500 mt-2">
                Questions are dynamically selected without repetition.
              </p>
            </div>
          </div>

          {/* Time Limit */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-end pt-2 border-t border-slate-200">
            <div>
              <label
                htmlFor="timeLimitInput"
                className="block text-sm font-semibold text-[#0F172A] mb-2"
              >
                Session Time Limit (Minutes)
              </label>
              <div className="flex items-center gap-3">
                <input
                  id="timeLimitInput"
                  type="number"
                  min={5}
                  max={120}
                  value={timeLimitMinutes}
                  onChange={(e) =>
                    setTimeLimitMinutes(Math.max(5, Math.min(120, Number(e.target.value) || 15)))
                  }
                  className="w-28 px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1D4ED8]/20 focus:border-[#1D4ED8] tabular-nums"
                />
                <span className="text-xs text-slate-500">
                  Recommended: {totalQuestions * 3} minutes (~3 min/question)
                </span>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={starting}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60"
              >
                {starting ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Play className="w-4 h-4" />
                )}
                Start Interview
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
