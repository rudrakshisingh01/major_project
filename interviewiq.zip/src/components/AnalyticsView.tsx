import React, { useEffect, useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { BarChart3, Loader2 } from 'lucide-react';
import { apiRequest } from '../lib/api';
import { AppRoute } from './AppLayout';

interface AnalyticsPayload {
  overview: {
    totalInterviews: number;
    totalQuestionsAnswered: number;
    overallAccuracy: number;
    avgTimePerQuestion: number;
  };
  scoreTimeline: Array<{
    attempt: string;
    date: string;
    percentage: number;
    totalScore: number;
    role: string;
    category: string;
    durationMinutes: number;
  }>;
  topicPerformance: Array<{
    topic: string;
    averageScore: number;
    accuracy: number;
    avgTimeSeconds: number;
    attempts: number;
  }>;
  categoryComparison: Array<{
    category: string;
    avgPercentage: number;
    accuracy: number;
    questions: number;
  }>;
  difficultyBreakdown: Array<{
    difficulty: string;
    avgPercentage: number;
    avgTimeSeconds: number;
    questionsAttempted: number;
  }>;
  recommendations: {
    weakTopics: Array<{
      topic: string;
      averageScore: number;
      accuracyPercentage: number;
      reason: string;
    }>;
  };
}

export function AnalyticsView({ onNavigate }: { onNavigate: (route: AppRoute) => void }) {
  const [data, setData] = useState<AnalyticsPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    apiRequest<AnalyticsPayload>('/api/analytics')
      .then((res) => {
        if (active) setData(res);
      })
      .catch((err: any) => {
        if (active) setError(err.message || 'Failed to load analytics.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
        <Loader2 className="w-6 h-6 animate-spin text-[#1D4ED8] mx-auto" />
        <p className="text-sm text-slate-600 mt-3">Loading longitudinal analytics...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="bg-white border border-red-200 rounded-xl p-6 text-sm text-red-700">
        {error || 'Unable to load analytics.'}
      </div>
    );
  }

  if (data.overview.totalInterviews === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center max-w-xl mx-auto">
        <BarChart3 className="w-10 h-10 text-slate-300 mx-auto" />
        <h2 className="font-display text-xl font-bold text-[#0F172A] mt-4">
          No Performance Analytics Yet
        </h2>
        <p className="text-sm text-slate-600 mt-2">
          Complete at least one mock interview to unlock score trends, Technical vs HR comparisons,
          time management metrics, and weak topic detection.
        </p>
        <button
          type="button"
          onClick={() => onNavigate('setup')}
          className="mt-6 px-5 py-2.5 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg cursor-pointer"
        >
          Start Your First Interview
        </button>
      </div>
    );
  }

  const shortTopicData = data.topicPerformance.map((t) => ({
    ...t,
    shortTopic: t.topic.length > 16 ? `${t.topic.slice(0, 14)}..` : t.topic,
    scorePct: Number((t.averageScore * 10).toFixed(1)),
  }));

  return (
    <div className="space-y-6">
      {/* Top Overview KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Completed Interviews</div>
          <div className="font-mono text-2xl font-bold text-[#0F172A] mt-1.5 tabular-nums">
            {data.overview.totalInterviews}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Questions Evaluated</div>
          <div className="font-mono text-2xl font-bold text-[#0F172A] mt-1.5 tabular-nums">
            {data.overview.totalQuestionsAnswered}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Overall Accuracy</div>
          <div className="font-mono text-2xl font-bold text-emerald-700 mt-1.5 tabular-nums">
            {data.overview.overallAccuracy}%
          </div>
          <div className="text-xs text-slate-500 mt-0.5">Responses scoring ≥ 6.0/10</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Avg Time per Question</div>
          <div className="font-mono text-2xl font-bold text-[#1D4ED8] mt-1.5 tabular-nums">
            {data.overview.avgTimePerQuestion}s
          </div>
          <div className="text-xs text-slate-500 mt-0.5">Response pacing metric</div>
        </div>
      </div>

      {/* Row 1 Charts: Performance Improvement Over Time & Interview-wise Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="font-display text-base font-semibold text-[#0F172A]">
            Performance Improvement Over Time
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Chronological score percentage trajectory across attempts
          </p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={data.scoreTimeline}
                margin={{ top: 10, right: 12, left: -16, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="analyticsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#1D4ED8" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#1D4ED8" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="date" tick={{ fontSize: 12, fill: '#64748B' }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: '#64748B' }} />
                <Tooltip
                  formatter={(v: any) => [`${v}%`, 'Score']}
                  contentStyle={{ borderRadius: '8px', border: '1px solid #E2E8F0', fontSize: '12px' }}
                />
                <Area
                  type="monotone"
                  dataKey="percentage"
                  stroke="#1D4ED8"
                  strokeWidth={2.5}
                  fill="url(#analyticsGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="font-display text-base font-semibold text-[#0F172A]">
            Interview-Wise Score Comparison
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Side-by-side comparison across each completed interview attempt
          </p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={data.scoreTimeline}
                margin={{ top: 10, right: 12, left: -16, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="attempt" tick={{ fontSize: 12, fill: '#64748B' }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: '#64748B' }} />
                <Tooltip
                  formatter={(v: any) => [`${v}%`, 'Score']}
                  contentStyle={{ borderRadius: '8px', border: '1px solid #E2E8F0', fontSize: '12px' }}
                />
                <Bar dataKey="percentage" fill="#0F172A" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Row 2 Charts: Topic-wise Performance & Technical vs HR */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="font-display text-base font-semibold text-[#0F172A]">
            Topic-Wise Accuracy &amp; Score
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Average score (%) across each evaluated CS &amp; Behavioral subject
          </p>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={shortTopicData}
                margin={{ top: 10, right: 12, left: -16, bottom: 20 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis
                  dataKey="shortTopic"
                  tick={{ fontSize: 11, fill: '#64748B' }}
                  angle={-18}
                  textAnchor="end"
                />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: '#64748B' }} />
                <Tooltip
                  formatter={(v: any) => [`${v}%`, 'Avg Score']}
                  contentStyle={{ borderRadius: '8px', border: '1px solid #E2E8F0', fontSize: '12px' }}
                />
                <Bar dataKey="scorePct" fill="#6D28D9" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          <div>
            <h3 className="font-display text-base font-semibold text-[#0F172A]">
              Technical vs HR Performance
            </h3>
            <p className="text-xs text-slate-500 mb-3">
              Category accuracy and average score comparison
            </p>
            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={data.categoryComparison}
                  layout="vertical"
                  margin={{ top: 4, right: 16, left: 10, bottom: 4 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: '#64748B' }} />
                  <YAxis
                    dataKey="category"
                    type="category"
                    tick={{ fontSize: 12, fill: '#0F172A' }}
                    width={72}
                  />
                  <Tooltip
                    formatter={(v: any) => [`${v}%`, 'Avg Score']}
                    contentStyle={{ borderRadius: '8px', border: '1px solid #E2E8F0', fontSize: '12px' }}
                  />
                  <Bar dataKey="avgPercentage" fill="#1D4ED8" radius={[0, 6, 6, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="border-t border-slate-200 pt-4">
            <h4 className="font-display text-sm font-semibold text-[#0F172A] mb-2">
              Time Management by Difficulty Tier
            </h4>
            <div className="space-y-2">
              {data.difficultyBreakdown.map((row) => (
                <div
                  key={row.difficulty}
                  className="flex items-center justify-between text-xs py-1.5 border-b border-slate-100 last:border-0"
                >
                  <span className="font-medium text-slate-700">{row.difficulty}</span>
                  <span className="font-mono text-slate-600 tabular-nums">
                    {row.questionsAttempted} Qs · Avg {row.avgPercentage}% · {row.avgTimeSeconds}s/Q
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Weak Topic Identification */}
      <div className="bg-white border border-slate-200 rounded-xl p-6">
        <div className="flex items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="font-display text-base font-semibold text-[#0F172A]">
              Weak Topic Identification &amp; Practice Areas
            </h3>
            <p className="text-xs text-slate-500">
              Subjects scoring below 6.5/10 or under 60% accuracy
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('recommendations')}
            className="text-xs font-semibold text-[#1D4ED8] hover:underline cursor-pointer"
          >
            View Recommended Questions
          </button>
        </div>

        {data.recommendations.weakTopics.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {data.recommendations.weakTopics.map((wt) => (
              <div
                key={wt.topic}
                className="p-4 rounded-xl border border-amber-200 bg-amber-50/40 space-y-1.5"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-semibold text-sm text-[#0F172A]">{wt.topic}</span>
                  <span className="font-mono text-xs font-bold text-amber-800 tabular-nums">
                    {wt.averageScore.toFixed(1)}/10
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{wt.reason}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-slate-600">
            No weak topics flagged right now—all practiced topics are performing above benchmark.
          </p>
        )}
      </div>
    </div>
  );
}
