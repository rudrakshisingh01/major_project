import React, { useCallback, useEffect, useState } from 'react';
import { ChevronDown, ChevronUp, Loader2, Plus, Search, Trash2, X } from 'lucide-react';
import { apiRequest } from '../lib/api';
import {
  DIFFICULTY_LEVELS,
  JOB_ROLES,
  TOPICS,
} from '../lib/constants';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

interface QuestionItem {
  id: number;
  questionCode: string;
  questionText: string;
  topic: string;
  jobRole: string;
  category: string;
  difficulty: string;
  expectedAnswer: string;
  evaluationKeywords: string[];
  evaluationCriteria: string;
  marks: number;
  createdByUid: string | null;
}

export function QuestionBankView() {
  const { user } = useAuth();
  const { showToast } = useToast();

  const [questions, setQuestions] = useState<QuestionItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [topicFilter, setTopicFilter] = useState('All');
  const [roleFilter, setRoleFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [difficultyFilter, setDifficultyFilter] = useState('All');
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    questionText: '',
    topic: TOPICS[0] as string,
    jobRole: JOB_ROLES[7] as string,
    category: 'Technical Interview',
    difficulty: 'Intermediate',
    expectedAnswer: '',
    evaluationKeywords: '',
    evaluationCriteria: '',
  });

  const loadQuestions = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search.trim()) params.set('search', search.trim());
      if (topicFilter !== 'All') params.set('topic', topicFilter);
      if (roleFilter !== 'All') params.set('role', roleFilter);
      if (categoryFilter !== 'All') params.set('category', categoryFilter);
      if (difficultyFilter !== 'All') params.set('difficulty', difficultyFilter);

      const res = await apiRequest<{ questions: QuestionItem[] }>(
        `/api/questions?${params.toString()}`
      );
      setQuestions(res.questions);
    } catch (err: any) {
      showToast(err.message || 'Failed to load question bank.', 'error');
    } finally {
      setLoading(false);
    }
  }, [search, topicFilter, roleFilter, categoryFilter, difficultyFilter, showToast]);

  useEffect(() => {
    const t = setTimeout(() => {
      loadQuestions();
    }, 200);
    return () => clearTimeout(t);
  }, [loadQuestions]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await apiRequest('/api/questions', {
        method: 'POST',
        body: JSON.stringify(form),
      });
      showToast('Custom question added to Question Bank.', 'success');
      setShowAddModal(false);
      setForm({
        questionText: '',
        topic: TOPICS[0],
        jobRole: JOB_ROLES[7],
        category: 'Technical Interview',
        difficulty: 'Intermediate',
        expectedAnswer: '',
        evaluationKeywords: '',
        evaluationCriteria: '',
      });
      await loadQuestions();
    } catch (err: any) {
      showToast(err.message || 'Failed to add question.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await apiRequest(`/api/questions/${id}`, { method: 'DELETE' });
      showToast('Custom question deleted.', 'success');
      setQuestions((prev) => prev.filter((q) => q.id !== id));
    } catch (err: any) {
      showToast(err.message || 'Unable to delete question.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-xl font-bold text-[#0F172A]">
              Structured Question Bank
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Browse <span className="font-mono font-semibold tabular-nums">{questions.length}</span>{' '}
              curated Technical and HR questions with evaluation rubrics and reference answers.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Question
          </button>
        </div>

        {/* Search & Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="relative lg:col-span-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search questions..."
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1D4ED8]/20 focus:border-[#1D4ED8]"
            />
          </div>

          <select
            value={topicFilter}
            onChange={(e) => setTopicFilter(e.target.value)}
            className="px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-[#1D4ED8]/20"
          >
            <option value="All">All Topics (12)</option>
            {TOPICS.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>

          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-[#1D4ED8]/20"
          >
            <option value="All">All Job Roles</option>
            {JOB_ROLES.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-[#1D4ED8]/20"
          >
            <option value="All">All Categories</option>
            <option value="Technical Interview">Technical Interview</option>
            <option value="HR Interview">HR Interview</option>
          </select>

          <select
            value={difficultyFilter}
            onChange={(e) => setDifficultyFilter(e.target.value)}
            className="px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-[#1D4ED8]/20"
          >
            <option value="All">All Difficulties</option>
            {DIFFICULTY_LEVELS.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Questions List */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-10 text-center">
            <Loader2 className="w-6 h-6 animate-spin text-[#1D4ED8] mx-auto" />
          </div>
        ) : questions.length === 0 ? (
          <div className="p-10 text-center text-sm text-slate-500">
            No questions match your current filters. Try clearing your search or selecting All
            Topics.
          </div>
        ) : (
          <div className="divide-y divide-slate-200">
            {questions.map((q) => {
              const isOpen = expandedId === q.id;
              const isOwner = user && q.createdByUid === user.uid;

              return (
                <div key={q.id} className="p-5 hover:bg-slate-50/50 transition-colors">
                  <div className="flex items-start justify-between gap-4">
                    <button
                      type="button"
                      onClick={() => setExpandedId(isOpen ? null : q.id)}
                      className="flex-1 text-left cursor-pointer"
                    >
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-1">
                        <span className="font-mono font-semibold text-slate-700">
                          {q.questionCode}
                        </span>
                        <span>·</span>
                        <span>{q.topic}</span>
                        <span>·</span>
                        <span>{q.jobRole}</span>
                        <span>·</span>
                        <span
                          className={`font-semibold ${
                            q.difficulty === 'Advanced'
                              ? 'text-[#6D28D9]'
                              : q.difficulty === 'Intermediate'
                              ? 'text-[#1D4ED8]'
                              : 'text-emerald-700'
                          }`}
                        >
                          {q.difficulty}
                        </span>
                        <span>·</span>
                        <span className="font-mono tabular-nums">{q.marks} Marks</span>
                      </div>
                      <div className="font-medium text-[#0F172A] leading-snug">
                        {q.questionText}
                      </div>
                    </button>

                    <div className="flex items-center gap-2 shrink-0">
                      {isOwner && (
                        <button
                          type="button"
                          onClick={() => handleDelete(q.id)}
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded-md transition-colors cursor-pointer"
                          aria-label="Delete custom question"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setExpandedId(isOpen ? null : q.id)}
                        className="p-1.5 text-slate-400 hover:text-slate-700 cursor-pointer"
                        aria-label="Toggle question details"
                      >
                        {isOpen ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>

                  {isOpen && (
                    <div className="mt-4 pt-4 border-t border-slate-100 space-y-3 text-sm">
                      <div>
                        <div className="text-xs font-semibold text-slate-500">
                          Expected Reference Answer
                        </div>
                        <p className="text-slate-700 mt-1 leading-relaxed bg-slate-50 border border-slate-200 rounded-lg p-3.5">
                          {q.expectedAnswer}
                        </p>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <div className="text-xs font-semibold text-slate-500">
                            Evaluation Keywords
                          </div>
                          <p className="text-xs text-slate-700 mt-1 leading-relaxed">
                            {q.evaluationKeywords.join(' · ')}
                          </p>
                        </div>
                        <div>
                          <div className="text-xs font-semibold text-slate-500">
                            Scoring Criteria
                          </div>
                          <p className="text-xs text-slate-700 mt-1 leading-relaxed">
                            {q.evaluationCriteria}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add Question Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full p-6 shadow-xl my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <h3 className="font-display text-lg font-bold text-[#0F172A]">
                Add Custom Practice Question
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Question Text
                </label>
                <textarea
                  rows={3}
                  required
                  value={form.questionText}
                  onChange={(e) => setForm({ ...form, questionText: e.target.value })}
                  placeholder="Enter the interview prompt..."
                  className="w-full p-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1D4ED8]/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Topic</label>
                  <select
                    value={form.topic}
                    onChange={(e) => setForm({ ...form, topic: e.target.value })}
                    className="w-full p-2 text-sm border border-slate-300 rounded-lg bg-white"
                  >
                    {TOPICS.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Job Role
                  </label>
                  <select
                    value={form.jobRole}
                    onChange={(e) => setForm({ ...form, jobRole: e.target.value })}
                    className="w-full p-2 text-sm border border-slate-300 rounded-lg bg-white"
                  >
                    {JOB_ROLES.map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Category
                  </label>
                  <select
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="w-full p-2 text-sm border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Technical Interview">Technical Interview</option>
                    <option value="HR Interview">HR Interview</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Difficulty
                  </label>
                  <select
                    value={form.difficulty}
                    onChange={(e) => setForm({ ...form, difficulty: e.target.value })}
                    className="w-full p-2 text-sm border border-slate-300 rounded-lg bg-white"
                  >
                    {DIFFICULTY_LEVELS.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Expected Answer
                </label>
                <textarea
                  rows={3}
                  required
                  value={form.expectedAnswer}
                  onChange={(e) => setForm({ ...form, expectedAnswer: e.target.value })}
                  placeholder="Provide the ideal reference answer..."
                  className="w-full p-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1D4ED8]/20"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Evaluation Keywords (comma-separated, min 2)
                </label>
                <input
                  type="text"
                  required
                  value={form.evaluationKeywords}
                  onChange={(e) => setForm({ ...form, evaluationKeywords: e.target.value })}
                  placeholder="e.g. indexing, B-Tree, O(log n), write overhead"
                  className="w-full p-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1D4ED8]/20"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Evaluation Criteria
                </label>
                <input
                  type="text"
                  value={form.evaluationCriteria}
                  onChange={(e) => setForm({ ...form, evaluationCriteria: e.target.value })}
                  placeholder="Describe what earns full marks..."
                  className="w-full p-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1D4ED8]/20"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg cursor-pointer disabled:opacity-60"
                >
                  {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                  Save Question
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
