import React, { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clock,
  Loader2,
  Send,
  TrendingDown,
  TrendingUp,
  Minus,
} from 'lucide-react';
import { apiRequest } from '../lib/api';
import { useToast } from '../context/ToastContext';

interface QuestionData {
  id: number;
  questionCode: string;
  questionText: string;
  topic: string;
  jobRole: string;
  category: string;
  difficulty: string;
  expectedAnswer: string;
  evaluationKeywords: string[];
  evaluationCriteria: string;
  marks: number;
}

interface AnswerSlot {
  id: number;
  questionId: number;
  questionOrder: number;
  difficultyAtTime: string;
  userAnswer: string;
  draftAnswer: string;
  score: number;
  maxMarks: number;
  isSubmitted: boolean;
  correctnessLevel: string;
  feedback: string;
  matchedKeywords: string[];
  missingConcepts: string[];
  suggestedImprovements: string;
  scoreBreakdown: {
    keywordRelevance: number;
    conceptualUnderstanding: number;
    completeness: number;
    relevance: number;
  };
  adaptiveMessage: string;
  nextDifficulty: string;
  timeSpentSeconds: number;
  question?: QuestionData;
}

interface InterviewSession {
  id: number;
  jobRole: string;
  category: string;
  initialDifficulty: string;
  currentDifficulty: string;
  totalQuestions: number;
  answeredCount: number;
  timeLimitMinutes: number;
  status: string;
  totalScore: number;
  maxScore: number;
  percentage: number;
}

interface LiveInterviewViewProps {
  interviewId: number;
  initialData?: {
    interview: InterviewSession;
    currentSlot: AnswerSlot;
    currentQuestion: QuestionData;
  };
  onInterviewCompleted: (interviewId: number) => void;
}

export function LiveInterviewView({
  interviewId,
  initialData,
  onInterviewCompleted,
}: LiveInterviewViewProps) {
  const { showToast } = useToast();

  const [interview, setInterview] = useState<InterviewSession | null>(
    initialData?.interview ?? null
  );
  const [slots, setSlots] = useState<Array<AnswerSlot & { question: QuestionData }>>(() => {
    if (initialData) {
      return [{ ...initialData.currentSlot, question: initialData.currentQuestion }];
    }
    return [];
  });
  const [activeOrder, setActiveOrder] = useState<number>(1);
  const [answerText, setAnswerText] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(!initialData);
  const [submittingAnswer, setSubmittingAnswer] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [showConfirmFinish, setShowConfirmFinish] = useState(false);
  const [draftStatus, setDraftStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const [remainingSeconds, setRemainingSeconds] = useState<number>(
    (initialData?.interview.timeLimitMinutes || 15) * 60
  );
  const [totalElapsedSeconds, setTotalElapsedSeconds] = useState<number>(0);
  const [questionElapsedSeconds, setQuestionElapsedSeconds] = useState<number>(0);

  const autoSaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const autoCompletedRef = useRef(false);

  // Load full session if resuming
  useEffect(() => {
    if (initialData) return;
    let active = true;
    setLoading(true);
    apiRequest<{
      interview: InterviewSession;
      items: Array<AnswerSlot & { question: QuestionData }>;
    }>(`/api/interviews/${interviewId}`)
      .then((res) => {
        if (!active) return;
        setInterview(res.interview);
        setSlots(res.items);
        const totalBudget = res.interview.timeLimitMinutes * 60;
        setRemainingSeconds(totalBudget);
        const lastSlot = res.items[res.items.length - 1];
        if (lastSlot) {
          setActiveOrder(lastSlot.questionOrder);
          setAnswerText(lastSlot.isSubmitted ? lastSlot.userAnswer : lastSlot.draftAnswer || '');
        }
      })
      .catch((err: any) => {
        showToast(err.message || 'Failed to load interview session.', 'error');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [interviewId, initialData, showToast]);

  const activeSlot = slots.find((s) => s.questionOrder === activeOrder) ?? slots[slots.length - 1];

  // Countdown timer + per-question timer
  useEffect(() => {
    if (!interview || interview.status === 'completed') return;
    const timer = setInterval(() => {
      setTotalElapsedSeconds((prev) => prev + 1);
      if (activeSlot && !activeSlot.isSubmitted) {
        setQuestionElapsedSeconds((prev) => prev + 1);
      }
      setRemainingSeconds((prev) => {
        if (prev <= 1) {
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [interview, activeSlot]);

  // Auto-complete when countdown hits zero
  useEffect(() => {
    if (remainingSeconds === 0 && interview && interview.status !== 'completed' && !autoCompletedRef.current) {
      autoCompletedRef.current = true;
      showToast('Time limit reached. Finalizing your interview report...', 'info');
      handleFinalizeInterview();
    }
  });

  // Auto-save draft answer
  const handleAnswerChange = (val: string) => {
    setAnswerText(val);
    if (!activeSlot || activeSlot.isSubmitted) return;
    setDraftStatus('saving');
    if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current);
    autoSaveTimerRef.current = setTimeout(async () => {
      try {
        await apiRequest(`/api/interviews/${interviewId}/draft`, {
          method: 'POST',
          body: JSON.stringify({
            answerSlotId: activeSlot.id,
            draftAnswer: val,
            timeSpentSeconds: questionElapsedSeconds,
          }),
        });
        setDraftStatus('saved');
      } catch {
        setDraftStatus('idle');
      }
    }, 1500);
  };

  const handleSelectQuestionOrder = (order: number) => {
    const target = slots.find((s) => s.questionOrder === order);
    if (!target) return;
    setActiveOrder(order);
    setAnswerText(target.isSubmitted ? target.userAnswer : target.draftAnswer || '');
    setDraftStatus('idle');
  };

  const handleSubmitAnswer = async () => {
    if (!activeSlot || activeSlot.isSubmitted) return;
    setSubmittingAnswer(true);
    try {
      const res = await apiRequest<{
        evaluatedSlot: AnswerSlot;
        interview: InterviewSession;
        nextSlot: AnswerSlot | null;
        nextQuestion: QuestionData | null;
        isLastQuestion: boolean;
      }>(`/api/interviews/${interviewId}/answer`, {
        method: 'POST',
        body: JSON.stringify({
          answerSlotId: activeSlot.id,
          userAnswer: answerText,
          timeSpentSeconds: Math.max(5, questionElapsedSeconds),
        }),
      });

      setInterview(res.interview);
      setSlots((prev) => {
        const updated = prev.map((s) =>
          s.id === res.evaluatedSlot.id ? { ...res.evaluatedSlot, question: s.question } : s
        );
        if (res.nextSlot && res.nextQuestion) {
          const exists = updated.some((u) => u.id === res.nextSlot!.id);
          if (!exists) {
            updated.push({ ...res.nextSlot, question: res.nextQuestion });
          }
        }
        return updated;
      });
      setDraftStatus('idle');
      showToast('Answer evaluated and adaptive difficulty updated.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to evaluate answer.', 'error');
    } finally {
      setSubmittingAnswer(false);
    }
  };

  const handleNextQuestion = () => {
    const nextOrder = activeOrder + 1;
    const nextSlot = slots.find((s) => s.questionOrder === nextOrder);
    if (nextSlot) {
      setActiveOrder(nextOrder);
      setAnswerText(nextSlot.isSubmitted ? nextSlot.userAnswer : nextSlot.draftAnswer || '');
      setQuestionElapsedSeconds(0);
      setDraftStatus('idle');
    }
  };

  const handleFinalizeInterview = async () => {
    setCompleting(true);
    try {
      const res = await apiRequest<{ emailDispatchStatus: string | null }>(
        `/api/interviews/${interviewId}/complete`,
        {
          method: 'POST',
          body: JSON.stringify({
            durationSeconds: Math.max(15, totalElapsedSeconds),
          }),
        }
      );
      if (res.emailDispatchStatus === 'sent') {
        showToast('Interview completed! Summary email sent to your inbox.', 'success');
      } else {
        showToast('Interview completed! Performance report generated.', 'success');
      }
      onInterviewCompleted(interviewId);
    } catch (err: any) {
      showToast(err.message || 'Failed to complete interview.', 'error');
      setCompleting(false);
    }
  };

  if (loading || !interview || !activeSlot) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-10 text-center">
        <Loader2 className="w-6 h-6 animate-spin text-[#1D4ED8] mx-auto" />
        <p className="text-sm text-slate-600 mt-3">Loading adaptive interview session...</p>
      </div>
    );
  }

  const mins = Math.floor(remainingSeconds / 60);
  const secs = remainingSeconds % 60;
  const formattedTime = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  const isLowTime = remainingSeconds <= 120;
  const progressPct = Math.round((interview.answeredCount / interview.totalQuestions) * 100);
  const wordCount = answerText.trim() ? answerText.trim().split(/\s+/).length : 0;

  const isNextAvailable = slots.some((s) => s.questionOrder === activeOrder + 1);
  const isFinalQuestionSubmitted =
    activeSlot.isSubmitted && activeSlot.questionOrder >= interview.totalQuestions;

  return (
    <div className="max-w-5xl mx-auto space-y-5">
      {/* Top Session Control Strip */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs text-slate-500">
            {interview.jobRole} · {interview.category}
          </div>
          <div className="flex items-center gap-3 mt-1">
            <span className="font-display text-lg font-bold text-[#0F172A] tabular-nums">
              Question {activeSlot.questionOrder} of {interview.totalQuestions}
            </span>
            <span className="text-slate-300">·</span>
            <span className="text-sm font-semibold text-[#1D4ED8]">
              Difficulty: {activeSlot.difficultyAtTime}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border font-mono text-sm font-semibold tabular-nums ${
              isLowTime
                ? 'border-red-200 bg-red-50 text-red-700'
                : 'border-slate-200 bg-slate-50 text-[#0F172A]'
            }`}
          >
            <Clock className="w-4 h-4" />
            {formattedTime}
          </div>

          <button
            type="button"
            onClick={() => setShowConfirmFinish(true)}
            className="px-4 py-2 text-xs sm:text-sm font-semibold text-[#0F172A] bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Finish Interview
          </button>
        </div>
      </div>

      {/* Progress Bar & Question Navigation */}
      <div className="bg-white border border-slate-200 rounded-xl p-4">
        <div className="flex items-center justify-between text-xs text-slate-600 mb-2">
          <span>
            Progress: <strong className="tabular-nums">{interview.answeredCount}</strong> /{' '}
            <span className="tabular-nums">{interview.totalQuestions}</span> answered
          </span>
          <span className="font-mono tabular-nums">{progressPct}%</span>
        </div>
        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-[#1D4ED8] transition-all duration-300"
            style={{ width: `${progressPct}%` }}
          />
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          {slots.map((slot) => {
            const isActive = slot.questionOrder === activeOrder;
            return (
              <button
                key={slot.id}
                type="button"
                onClick={() => handleSelectQuestionOrder(slot.questionOrder)}
                className={`px-3 py-1 text-xs font-mono font-semibold rounded-md border transition-colors cursor-pointer tabular-nums ${
                  isActive
                    ? 'bg-[#0F172A] text-white border-[#0F172A]'
                    : slot.isSubmitted
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Q{slot.questionOrder}
              </button>
            );
          })}
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 mb-3">
          <span>
            {activeSlot.question.topic} · {activeSlot.question.category} ·{' '}
            {activeSlot.question.questionCode}
          </span>
          <span className="font-mono font-semibold text-slate-700 tabular-nums">
            Max Marks: {activeSlot.maxMarks}
          </span>
        </div>

        <h3 className="font-display text-xl sm:text-2xl font-semibold text-[#0F172A] leading-snug">
          {activeSlot.question.questionText}
        </h3>

        <div className="mt-6">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <label htmlFor="answerInput" className="font-medium text-slate-700">
              Your Response
            </label>
            <div className="flex items-center gap-3">
              {draftStatus === 'saving' && <span>Saving draft...</span>}
              {draftStatus === 'saved' && <span className="text-emerald-700">Draft saved</span>}
              <span className="font-mono tabular-nums">{wordCount} words</span>
            </div>
          </div>

          <textarea
            id="answerInput"
            rows={7}
            disabled={activeSlot.isSubmitted || submittingAnswer}
            value={answerText}
            onChange={(e) => handleAnswerChange(e.target.value)}
            placeholder="Write a clear, structured explanation covering core concepts, trade-offs, and examples..."
            className="w-full p-4 text-sm text-[#0F172A] bg-[#F8FAFC] border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1D4ED8]/20 focus:border-[#1D4ED8] disabled:bg-slate-50 disabled:text-slate-700 leading-relaxed"
          />
        </div>

        {!activeSlot.isSubmitted && (
          <div className="mt-5 flex items-center justify-end">
            <button
              type="button"
              disabled={submittingAnswer}
              onClick={handleSubmitAnswer}
              className="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg transition-colors cursor-pointer disabled:opacity-60"
            >
              {submittingAnswer ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
              Submit Answer
            </button>
          </div>
        )}
      </div>

      {/* Immediate Evaluation & Adaptive Engine Decision Panel */}
      {activeSlot.isSubmitted && (
        <div className="space-y-4">
          {/* Adaptive Decision Callout */}
          <div className="bg-[#0F172A] text-white rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center shrink-0">
                {activeSlot.nextDifficulty !== activeSlot.difficultyAtTime ? (
                  activeSlot.score >= 8 ? (
                    <TrendingUp className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <TrendingDown className="w-5 h-5 text-amber-400" />
                  )
                ) : (
                  <Minus className="w-5 h-5 text-blue-300" />
                )}
              </div>
              <div>
                <div className="text-xs font-medium text-blue-300">
                  Adaptive Assessment Decision · Next Tier: {activeSlot.nextDifficulty}
                </div>
                <p className="text-sm font-medium text-white mt-0.5">
                  {activeSlot.adaptiveMessage}
                </p>
              </div>
            </div>

            {isNextAvailable && !isFinalQuestionSubmitted ? (
              <button
                type="button"
                onClick={handleNextQuestion}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-[#0F172A] bg-white hover:bg-slate-100 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Next Question
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : isFinalQuestionSubmitted ? (
              <button
                type="button"
                disabled={completing}
                onClick={handleFinalizeInterview}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60"
              >
                {completing && <Loader2 className="w-4 h-4 animate-spin" />}
                Generate Final Report
              </button>
            ) : null}
          </div>

          {/* Detailed Rule-Based Evaluation Card */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
              <div>
                <div className="text-xs text-slate-500">
                  Rule-Based Evaluation Result · {activeSlot.correctnessLevel}
                </div>
                <div className="font-mono text-2xl font-bold text-[#0F172A] mt-0.5 tabular-nums">
                  {activeSlot.score.toFixed(1)} / {activeSlot.maxMarks}
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
                  <div className="text-slate-500">Keywords</div>
                  <div className="font-mono font-semibold text-[#0F172A] tabular-nums mt-0.5">
                    {activeSlot.scoreBreakdown?.keywordRelevance ?? 0} / 4.0
                  </div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
                  <div className="text-slate-500">Concepts</div>
                  <div className="font-mono font-semibold text-[#0F172A] tabular-nums mt-0.5">
                    {activeSlot.scoreBreakdown?.conceptualUnderstanding ?? 0} / 2.5
                  </div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
                  <div className="text-slate-500">Completeness</div>
                  <div className="font-mono font-semibold text-[#0F172A] tabular-nums mt-0.5">
                    {activeSlot.scoreBreakdown?.completeness ?? 0} / 2.0
                  </div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
                  <div className="text-slate-500">Relevance</div>
                  <div className="font-mono font-semibold text-[#0F172A] tabular-nums mt-0.5">
                    {activeSlot.scoreBreakdown?.relevance ?? 0} / 1.5
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              <div className="space-y-3">
                <div>
                  <div className="font-semibold text-[#0F172A] mb-1">Correctness Feedback</div>
                  <p className="text-slate-600 leading-relaxed">{activeSlot.feedback}</p>
                </div>
                <div>
                  <div className="font-semibold text-[#0F172A] mb-1">Suggested Improvements</div>
                  <p className="text-slate-600 leading-relaxed">
                    {activeSlot.suggestedImprovements}
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <div className="font-semibold text-emerald-800 mb-1 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    Matched Key Concepts ({activeSlot.matchedKeywords.length})
                  </div>
                  <p className="text-slate-600 text-xs leading-relaxed">
                    {activeSlot.matchedKeywords.length > 0
                      ? activeSlot.matchedKeywords.join(' · ')
                      : 'None matched'}
                  </p>
                </div>
                <div>
                  <div className="font-semibold text-amber-800 mb-1 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4" />
                    Missing Key Concepts ({activeSlot.missingConcepts.length})
                  </div>
                  <p className="text-slate-600 text-xs leading-relaxed">
                    {activeSlot.missingConcepts.length > 0
                      ? activeSlot.missingConcepts.join(' · ')
                      : 'All primary rubric concepts covered!'}
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200">
              <div className="text-xs font-semibold text-slate-700 mb-1">
                Expected Model Answer
              </div>
              <p className="text-sm text-slate-700 bg-slate-50 border border-slate-200 rounded-lg p-4 leading-relaxed">
                {activeSlot.question.expectedAnswer}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {showConfirmFinish && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-xl">
            <h3 className="font-display text-lg font-bold text-[#0F172A]">
              Finish &amp; Submit Interview?
            </h3>
            <p className="text-sm text-slate-600 mt-2">
              You have submitted{' '}
              <strong className="tabular-nums">{interview.answeredCount}</strong> of{' '}
              <strong className="tabular-nums">{interview.totalQuestions}</strong> questions.
              Finishing now will calculate your final report and update your performance analytics.
            </p>
            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowConfirmFinish(false)}
                className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Continue Interview
              </button>
              <button
                type="button"
                disabled={completing}
                onClick={handleFinalizeInterview}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg cursor-pointer disabled:opacity-60"
              >
                {completing && <Loader2 className="w-4 h-4 animate-spin" />}
                Submit &amp; View Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
