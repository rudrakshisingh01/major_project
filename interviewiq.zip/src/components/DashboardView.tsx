import React, { useEffect, useState } from 'react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ArrowRight, PlayCircle, TrendingUp } from 'lucide-react';
import { apiRequest } from '../lib/api';
import { AppRoute } from './AppLayout';

interface DashboardData {
  profile: {
    fullName: string;
    targetRole: string;
    experienceLevel: string;
  };
  summary: {
    totalInterviews: number;
    averageScore: number;
    bestScore: number;
    totalQuestionsAnswered: number;
    performanceLevel: string;
  };
  recentInterviews: Array<{
    id: number;
    jobRole: string;
    category: string;
    initialDifficulty: string;
    currentDifficulty: string;
    totalScore: number;
    maxScore: number;
    percentage: number;
    status: string;
    durationSeconds: number;
    startedAt: string;
  }>;
  weeklyChart: Array<{
    label: string;
    session: string;
    score: number;
    role: string;
  }>;
  strengths: Array<{
    topic: string;
    averageScore: number;
    accuracy: number;
    questionsAttempted: number;
  }>;
  weaknesses: Array<{
    topic: string;
    averageScore: number;
    accuracy: number;
    questionsAttempted: number;
  }>;
  recommendations: {
    suggestedDifficulty: string;
    preparationSummary: string;
    weakTopics: Array<{
      topic: string;
      averageScore: number;
      priority: string;
      reason: string;
    }>;
  };
}

interface DashboardViewProps {
  onNavigate: (route: AppRoute) => void;
  onOpenInterview: (interviewId: number, status: string) => void;
}

export function DashboardView({ onNavigate, onOpenInterview }: DashboardViewProps) {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    apiRequest<DashboardData>('/api/dashboard')
      .then((res) => {
        if (active) {
          setData(res);
          setError(null);
        }
      })
      .catch((err: any) => {
        if (active) setError(err.message || 'Failed to load dashboard.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-24 bg-white border border-slate-200 rounded-xl animate-pulse" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {[1, 2, 3, 4, 5].map((n) => (
            <div
              key={n}
              className="h-28 bg-white border border-slate-200 rounded-xl animate-pulse"
            />
          ))}
        </div>
        <div className="h-72 bg-white border border-slate-200 rounded-xl animate-pulse" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="bg-white border border-red-200 rounded-xl p-6 text-sm text-red-700">
        {error || 'Unable to load dashboard data.'}
      </div>
    );
  }

  const { profile, summary, recentInterviews, weeklyChart, strengths, weaknesses, recommendations } =
    data;

  const hasAttempts = summary.totalInterviews > 0;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <p className="text-sm text-slate-500">
            Target Role: {profile.targetRole} · Recommended Start: {recommendations.suggestedDifficulty}
          </p>
          <h2 className="font-display text-2xl font-bold text-[#0F172A] mt-1">
            Welcome back, {profile.fullName}
          </h2>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">
            {recommendations.preparationSummary}
          </p>
        </div>

        <button
          type="button"
          onClick={() => onNavigate('setup')}
          className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <PlayCircle className="w-4 h-4" />
          Quick Start Interview
        </button>
      </div>

      {/* 5-Metric KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Interviews Attempted</div>
          <div className="font-mono text-2xl font-semibold text-[#0F172A] mt-2 tabular-nums">
            {summary.totalInterviews}
          </div>
          <div className="text-xs text-slate-500 mt-1">Completed sessions</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Average Score</div>
          <div className="font-mono text-2xl font-semibold text-[#1D4ED8] mt-2 tabular-nums">
            {summary.averageScore.toFixed(1)}%
          </div>
          <div className="text-xs text-slate-500 mt-1">Across all attempts</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Best Performance</div>
          <div className="font-mono text-2xl font-semibold text-emerald-700 mt-2 tabular-nums">
            {summary.bestScore.toFixed(1)}%
          </div>
          <div className="text-xs text-slate-500 mt-1">Personal high mark</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Questions Answered</div>
          <div className="font-mono text-2xl font-semibold text-[#0F172A] mt-2 tabular-nums">
            {summary.totalQuestionsAnswered}
          </div>
          <div className="text-xs text-slate-500 mt-1">Evaluated responses</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Performance Level</div>
          <div className="font-display text-xl font-bold text-[#6D28D9] mt-2">
            {summary.performanceLevel}
          </div>
          <div className="text-xs text-slate-500 mt-1">Current readiness tier</div>
        </div>
      </div>

      {/* Charts + Topic Mastery Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6">
          <div className="flex items-center justify-between gap-4 mb-4">
            <div>
              <h3 className="font-display text-lg font-semibold text-[#0F172A]">
                Performance Trajectory
              </h3>
              <p className="text-xs text-slate-500">
                Score percentage across your recent completed mock interviews
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('analytics')}
              className="text-xs font-semibold text-[#1D4ED8] hover:underline whitespace-nowrap shrink-0 cursor-pointer"
            >
              Full Analytics
            </button>
          </div>

          {weeklyChart.length > 0 ? (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={weeklyChart} margin={{ top: 10, right: 12, left: -16, bottom: 0 }}>
                  <defs>
                    <linearGradient id="dashScoreGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#1D4ED8" stopOpacity={0.22} />
                      <stop offset="95%" stopColor="#1D4ED8" stopOpacity={0.01} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#64748B' }} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: '#64748B' }} />
                  <Tooltip
                    formatter={(value: any) => [`${value}%`, 'Score']}
                    contentStyle={{
                      borderRadius: '8px',
                      border: '1px solid #E2E8F0',
                      fontSize: '12px',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="score"
                    stroke="#1D4ED8"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#dashScoreGrad)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-64 flex flex-col items-center justify-center text-center border border-dashed border-slate-200 rounded-lg p-6">
              <TrendingUp className="w-8 h-8 text-slate-300 mb-2" />
              <p className="text-sm font-medium text-slate-700">No completed interviews yet</p>
              <p className="text-xs text-slate-500 mt-1 max-w-sm">
                Complete your first adaptive mock interview to plot your score trend here.
              </p>
              <button
                type="button"
                onClick={() => onNavigate('setup')}
                className="mt-4 px-4 py-2 text-xs font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg cursor-pointer"
              >
                Start First Interview
              </button>
            </div>
          )}
        </div>

        {/* Topic Strengths & Weaknesses */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-3 mb-4">
              <h3 className="font-display text-lg font-semibold text-[#0F172A]">
                Topic Mastery &amp; Focus Areas
              </h3>
              <button
                type="button"
                onClick={() => onNavigate('recommendations')}
                className="text-xs font-semibold text-[#1D4ED8] hover:underline whitespace-nowrap shrink-0 cursor-pointer"
              >
                Study Plan
              </button>
            </div>

            {hasAttempts ? (
              <div className="space-y-5">
                <div>
                  <div className="text-xs font-semibold text-emerald-700 mb-2">
                    Strongest Topics
                  </div>
                  {strengths.length > 0 ? (
                    <div className="space-y-2">
                      {strengths.slice(0, 3).map((item) => (
                        <div
                          key={item.topic}
                          className="flex items-center justify-between text-sm py-1.5 border-b border-slate-100 last:border-0"
                        >
                          <span className="text-slate-700 truncate pr-3">{item.topic}</span>
                          <span className="font-mono text-xs font-semibold text-emerald-700 tabular-nums shrink-0">
                            {item.averageScore.toFixed(1)}/10 · {item.accuracy}%
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-500">
                      Score 7.0/10 or above in topics to build your strengths list.
                    </p>
                  )}
                </div>

                <div>
                  <div className="text-xs font-semibold text-amber-700 mb-2">
                    Recommended Topics for Improvement
                  </div>
                  {weaknesses.length > 0 ? (
                    <div className="space-y-2">
                      {weaknesses.slice(0, 3).map((item) => (
                        <div
                          key={item.topic}
                          className="flex items-center justify-between text-sm py-1.5 border-b border-slate-100 last:border-0"
                        >
                          <span className="text-slate-700 truncate pr-3">{item.topic}</span>
                          <span className="font-mono text-xs font-semibold text-amber-700 tabular-nums shrink-0">
                            {item.averageScore.toFixed(1)}/10 · {item.accuracy}%
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-500">
                      All evaluated topics are currently above the 6.5/10 benchmark.
                    </p>
                  )}
                </div>
              </div>
            ) : (
              <div className="py-10 text-center text-sm text-slate-500">
                Strengths, weak topics, and customized improvement targets will appear here after
                your first evaluated session.
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => onNavigate('questions')}
            className="mt-6 w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-[#0F172A] bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            Browse 65+ Question Bank
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Recent Interview History */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="font-display text-lg font-semibold text-[#0F172A]">
              Recent Interview History
            </h3>
            <p className="text-xs text-slate-500">
              Your 5 most recent mock assessment attempts
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('history')}
            className="text-xs font-semibold text-[#1D4ED8] hover:underline whitespace-nowrap shrink-0 cursor-pointer"
          >
            View All History
          </button>
        </div>

        {recentInterviews.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-6">Date</th>
                  <th className="py-3 px-4">Job Role</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Difficulty Flow</th>
                  <th className="py-3 px-4 text-right">Score</th>
                  <th className="py-3 px-6 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {recentInterviews.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-6 text-slate-600 tabular-nums whitespace-nowrap">
                      {new Date(item.startedAt).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                      })}
                    </td>
                    <td className="py-3.5 px-4 font-medium text-[#0F172A]">{item.jobRole}</td>
                    <td className="py-3.5 px-4 text-slate-600">{item.category}</td>
                    <td className="py-3.5 px-4 text-slate-600 whitespace-nowrap">
                      {item.initialDifficulty} → {item.currentDifficulty}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-semibold text-[#0F172A] tabular-nums whitespace-nowrap">
                      {item.status === 'completed'
                        ? `${item.percentage.toFixed(1)}%`
                        : 'In Progress'}
                    </td>
                    <td className="py-3.5 px-6 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => onOpenInterview(item.id, item.status)}
                        className="text-xs font-semibold text-[#1D4ED8] hover:underline cursor-pointer"
                      >
                        {item.status === 'completed' ? 'View Report' : 'Resume'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-8 text-center text-sm text-slate-500">
            No interview sessions recorded yet. Click <strong>Quick Start Interview</strong> above
            to begin.
          </div>
        )}
      </div>
    </div>
  );
}
