import React, { useEffect, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ArrowLeft, ChevronDown, ChevronUp, Download, Loader2 } from 'lucide-react';
import { apiRequest } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { downloadInterviewReportPdf } from '../lib/pdfReport';

interface InterviewReportViewProps {
  interviewId: number;
  onBack: () => void;
}

export function InterviewReportView({ interviewId, onBack }: InterviewReportViewProps) {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [interview, setInterview] = useState<any>(null);
  const [items, setItems] = useState<any[]>([]);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    apiRequest<{ interview: any; items: any[] }>(`/api/interviews/${interviewId}`)
      .then((res) => {
        if (!active) return;
        setInterview(res.interview);
        setItems(res.items);
        if (res.items.length > 0) setExpandedId(res.items[0].id);
      })
      .catch((err: any) => {
        if (active) setError(err.message || 'Failed to load interview report.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [interviewId]);

  if (loading) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
        <Loader2 className="w-6 h-6 animate-spin text-[#1D4ED8] mx-auto" />
        <p className="text-sm text-slate-600 mt-3">Compiling detailed evaluation report...</p>
      </div>
    );
  }

  if (error || !interview) {
    return (
      <div className="bg-white border border-red-200 rounded-xl p-6 text-sm text-red-700">
        {error || 'Report not found.'}
      </div>
    );
  }

  const correctCount = items.filter((i) => i.score >= 7).length;
  const partialCount = items.filter((i) => i.score >= 4 && i.score < 7).length;
  const weakCount = items.filter((i) => i.score < 4).length;
  const avgTimePerQuestion =
    items.length > 0 ? Math.round(interview.durationSeconds / items.length) : 0;

  // Topic aggregation
  const topicMap = new Map<string, { sum: number; count: number }>();
  for (const item of items) {
    const t = item.question.topic;
    const cur = topicMap.get(t) ?? { sum: 0, count: 0 };
    cur.sum += item.score;
    cur.count += 1;
    topicMap.set(t, cur);
  }
  const topicChartData = Array.from(topicMap.entries()).map(([topic, val]) => ({
    topic: topic.length > 18 ? `${topic.slice(0, 16)}..` : topic,
    fullTopic: topic,
    avgScore: Number(((val.sum / val.count) * 10).toFixed(1)),
  }));

  const strengths = Array.from(topicMap.entries())
    .filter(([, val]) => val.sum / val.count >= 7)
    .map(([t]) => t);

  const weaknesses = Array.from(topicMap.entries())
    .filter(([, val]) => val.sum / val.count < 6.5)
    .map(([t]) => t);

  // Adaptive trajectory data
  const trajectoryData = items.map((item) => ({
    question: `Q${item.questionOrder}`,
    scorePct: Number(((item.score / item.maxMarks) * 100).toFixed(1)),
    difficultyLevel:
      item.difficultyAtTime === 'Advanced' ? 3 : item.difficultyAtTime === 'Intermediate' ? 2 : 1,
    difficultyLabel: item.difficultyAtTime,
  }));

  // Difficulty breakdown
  const difficultyBreakdown = ['Beginner', 'Intermediate', 'Advanced'].map((diff) => {
    const subset = items.filter((i) => i.difficultyAtTime === diff);
    const avg =
      subset.length > 0
        ? Number(
            ((subset.reduce((s, x) => s + x.score, 0) / (subset.length * 10)) * 100).toFixed(1)
          )
        : null;
    return { difficulty: diff, count: subset.length, avgPct: avg };
  });

  const handleDownloadPdf = () => {
    downloadInterviewReportPdf(
      profile?.fullName || 'Student',
      interview,
      items,
      strengths,
      weaknesses
    );
  };

  const mins = Math.floor(interview.durationSeconds / 60);
  const secs = interview.durationSeconds % 60;

  return (
    <div className="space-y-6">
      {/* Header & PDF Download */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1D4ED8] hover:underline mb-2 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Interview History
          </button>
          <h2 className="font-display text-2xl font-bold text-[#0F172A]">
            {interview.jobRole} — {interview.category}
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Completed {new Date(interview.completedAt || interview.startedAt).toLocaleString()} ·
            Adaptive Path: {interview.initialDifficulty} → {interview.currentDifficulty}
          </p>
        </div>

        <button
          type="button"
          onClick={handleDownloadPdf}
          className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#0F172A] hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Download className="w-4 h-4" />
          Download Report PDF
        </button>
      </div>

      {/* KPI Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Overall Score</div>
          <div className="font-mono text-xl font-bold text-[#0F172A] mt-1 tabular-nums">
            {interview.totalScore.toFixed(1)} / {interview.maxScore}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Percentage</div>
          <div className="font-mono text-xl font-bold text-[#1D4ED8] mt-1 tabular-nums">
            {interview.percentage.toFixed(1)}%
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Strong Answers</div>
          <div className="font-mono text-xl font-bold text-emerald-700 mt-1 tabular-nums">
            {correctCount}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Partial / Needs Work</div>
          <div className="font-mono text-xl font-bold text-amber-700 mt-1 tabular-nums">
            {partialCount + weakCount}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Total Time</div>
          <div className="font-mono text-xl font-bold text-[#0F172A] mt-1 tabular-nums">
            {mins}m {secs}s
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Avg Time / Question</div>
          <div className="font-mono text-xl font-bold text-[#0F172A] mt-1 tabular-nums">
            {avgTimePerQuestion}s
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="font-display text-base font-semibold text-[#0F172A]">
            Adaptive Question Score Progression
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Score percentage and adaptive difficulty per question
          </p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trajectoryData} margin={{ top: 10, right: 12, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="question" tick={{ fontSize: 12, fill: '#64748B' }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: '#64748B' }} />
                <Tooltip
                  formatter={(value: any, _name: any, props: any) => [
                    `${value}% (${props.payload.difficultyLabel})`,
                    'Score',
                  ]}
                  contentStyle={{ borderRadius: '8px', border: '1px solid #E2E8F0', fontSize: '12px' }}
                />
                <Line
                  type="monotone"
                  dataKey="scorePct"
                  stroke="#1D4ED8"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: '#1D4ED8' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="font-display text-base font-semibold text-[#0F172A]">
            Performance by Topic (%)
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Average topic accuracy in this interview
          </p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={topicChartData} margin={{ top: 10, right: 12, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="topic" tick={{ fontSize: 11, fill: '#64748B' }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: '#64748B' }} />
                <Tooltip
                  formatter={(value: any) => [`${value}%`, 'Topic Score']}
                  contentStyle={{ borderRadius: '8px', border: '1px solid #E2E8F0', fontSize: '12px' }}
                />
                <Bar dataKey="avgScore" fill="#6D28D9" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Difficulty Breakdown + Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="font-display text-base font-semibold text-[#0F172A] mb-4">
            Difficulty-Wise Performance
          </h3>
          <div className="space-y-3">
            {difficultyBreakdown.map((d) => (
              <div
                key={d.difficulty}
                className="flex items-center justify-between py-2.5 border-b border-slate-100 last:border-0"
              >
                <div>
                  <div className="text-sm font-medium text-[#0F172A]">{d.difficulty}</div>
                  <div className="text-xs text-slate-500 tabular-nums">
                    {d.count} question{d.count === 1 ? '' : 's'} attempted
                  </div>
                </div>
                <div className="font-mono text-sm font-semibold text-[#0F172A] tabular-nums">
                  {d.avgPct !== null ? `${d.avgPct}%` : '—'}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <h3 className="font-display text-base font-semibold text-[#0F172A]">
            Strengths, Weaknesses &amp; Improvement Plan
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <div className="p-4 rounded-lg bg-emerald-50/70 border border-emerald-200">
              <div className="font-semibold text-emerald-900">Strengths</div>
              <p className="text-emerald-800 text-xs mt-1 leading-relaxed">
                {strengths.length > 0
                  ? strengths.join(', ')
                  : 'Keep practicing to push topics above the 70% mastery threshold.'}
              </p>
            </div>
            <div className="p-4 rounded-lg bg-amber-50/70 border border-amber-200">
              <div className="font-semibold text-amber-900">Areas to Improve</div>
              <p className="text-amber-800 text-xs mt-1 leading-relaxed">
                {weaknesses.length > 0
                  ? weaknesses.join(', ')
                  : 'Great consistency—no critical weak topics detected in this session.'}
              </p>
            </div>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            {weaknesses.length > 0
              ? `Recommendation: Review the missing key concepts below for ${weaknesses.join(
                  ', '
                )}, then launch a focused Beginner/Intermediate practice session targeting those domains.`
              : 'Recommendation: Challenge yourself with an Advanced-tier Mixed Interview to validate edge-case mastery under time constraints.'}
          </p>
        </div>
      </div>

      {/* Question-by-Question Audit */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200">
          <h3 className="font-display text-lg font-semibold text-[#0F172A]">
            Question-by-Question Review
          </h3>
        </div>
        <div className="divide-y divide-slate-200">
          {items.map((item) => {
            const isExpanded = expandedId === item.id;
            return (
              <div key={item.id} className="p-5 sm:p-6">
                <button
                  type="button"
                  onClick={() => setExpandedId(isExpanded ? null : item.id)}
                  className="w-full flex items-start justify-between gap-4 text-left cursor-pointer"
                >
                  <div className="space-y-1">
                    <div className="text-xs text-slate-500">
                      Q{item.questionOrder} · {item.question.topic} · {item.difficultyAtTime} ·{' '}
                      {item.correctnessLevel}
                    </div>
                    <div className="font-medium text-[#0F172A]">{item.question.questionText}</div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="font-mono text-sm font-bold text-[#1D4ED8] tabular-nums">
                      {item.score.toFixed(1)}/{item.maxMarks}
                    </span>
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                </button>

                {isExpanded && (
                  <div className="mt-4 pt-4 border-t border-slate-100 space-y-3 text-sm">
                    <div>
                      <div className="text-xs font-semibold text-slate-500">Your Answer</div>
                      <p className="text-slate-700 mt-1 whitespace-pre-wrap">
                        {item.userAnswer || '(No answer submitted)'}
                      </p>
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-slate-500">Evaluation Feedback</div>
                      <p className="text-slate-700 mt-1">{item.feedback}</p>
                    </div>
                    {Array.isArray(item.missingConcepts) && item.missingConcepts.length > 0 && (
                      <div>
                        <div className="text-xs font-semibold text-amber-800">
                          Missing Key Concepts
                        </div>
                        <p className="text-xs text-slate-600 mt-1">
                          {item.missingConcepts.join(' · ')}
                        </p>
                      </div>
                    )}
                    <div>
                      <div className="text-xs font-semibold text-slate-500">
                        Expected Model Answer
                      </div>
                      <p className="text-slate-700 bg-slate-50 border border-slate-200 rounded-lg p-3 mt-1">
                        {item.question.expectedAnswer}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
