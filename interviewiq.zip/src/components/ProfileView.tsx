import React, { useEffect, useState } from 'react';
import { Bell, Download, Loader2, Mail, Save } from 'lucide-react';
import { useAuth, UserProfile } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { apiRequest } from '../lib/api';
import { downloadProjectSourceZip } from '../lib/downloadZip';
import { DIFFICULTY_LEVELS, JOB_ROLES } from '../lib/constants';

interface EmailNotificationLog {
  id: number;
  recipientEmail: string;
  eventType: string;
  subject: string;
  provider: string;
  deliveryStatus: string;
  sentAt: string;
}

export function ProfileView() {
  const { profile, setProfile } = useAuth();
  const { showToast } = useToast();

  const [form, setForm] = useState({
    fullName: profile?.fullName || '',
    targetRole: profile?.targetRole || 'Software Engineer',
    collegeName: profile?.collegeName || 'B.Tech Computer Science',
    graduationYear: profile?.graduationYear || '2026',
    experienceLevel: profile?.experienceLevel || 'Beginner',
    bio: profile?.bio || '',
    emailAlertsEnabled: profile?.emailAlertsEnabled ?? true,
  });
  const [saving, setSaving] = useState(false);
  const [logs, setLogs] = useState<EmailNotificationLog[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(true);

  useEffect(() => {
    if (profile) {
      setForm({
        fullName: profile.fullName,
        targetRole: profile.targetRole,
        collegeName: profile.collegeName,
        graduationYear: profile.graduationYear,
        experienceLevel: profile.experienceLevel,
        bio: profile.bio,
        emailAlertsEnabled: profile.emailAlertsEnabled,
      });
    }
  }, [profile]);

  useEffect(() => {
    let active = true;
    apiRequest<{ notifications: EmailNotificationLog[] }>('/api/notifications')
      .then((res) => {
        if (active) setLogs(res.notifications);
      })
      .catch(() => {})
      .finally(() => {
        if (active) setLoadingLogs(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.fullName.trim().length < 2) {
      showToast('Full name must be at least 2 characters.', 'error');
      return;
    }
    setSaving(true);
    try {
      const res = await apiRequest<{ profile: UserProfile }>('/api/profile', {
        method: 'PUT',
        body: JSON.stringify(form),
      });
      setProfile(res.profile);
      showToast('Profile and notification preferences updated.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update profile.', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-xl font-bold text-[#0F172A]">
              Student Profile &amp; Preferences
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Manage your academic details, target placement role, and transactional email alert
              settings.
            </p>
          </div>
          <button
            type="button"
            onClick={() =>
              downloadProjectSourceZip()
                .then(() => showToast('Source archive downloaded.', 'success'))
                .catch((err: any) => showToast(err.message || 'Download failed.', 'error'))
            }
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#0F172A] bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Download Source (.zip)
          </button>
        </div>

        <form onSubmit={handleSave} className="mt-6 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Full Name
              </label>
              <input
                type="text"
                required
                value={form.fullName}
                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1D4ED8]/20 focus:border-[#1D4ED8]"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Email Address
              </label>
              <input
                type="email"
                disabled
                value={profile?.email || ''}
                className="w-full px-3.5 py-2.5 text-sm border border-slate-200 bg-slate-50 text-slate-500 rounded-lg"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Target Job Role
              </label>
              <select
                value={form.targetRole}
                onChange={(e) => setForm({ ...form, targetRole: e.target.value })}
                className="w-full px-3 py-2.5 text-sm border border-slate-300 rounded-lg bg-white"
              >
                {JOB_ROLES.map((role) => (
                  <option key={role} value={role}>
                    {role}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Current Skill Tier
              </label>
              <select
                value={form.experienceLevel}
                onChange={(e) => setForm({ ...form, experienceLevel: e.target.value })}
                className="w-full px-3 py-2.5 text-sm border border-slate-300 rounded-lg bg-white"
              >
                {DIFFICULTY_LEVELS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Graduation Year
              </label>
              <input
                type="text"
                value={form.graduationYear}
                onChange={(e) => setForm({ ...form, graduationYear: e.target.value })}
                className="w-full px-3.5 py-2.5 text-sm font-mono border border-slate-300 rounded-lg tabular-nums"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">
              College / Department
            </label>
            <input
              type="text"
              value={form.collegeName}
              onChange={(e) => setForm({ ...form, collegeName: e.target.value })}
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">
              Preparation Goal / Bio
            </label>
            <textarea
              rows={3}
              value={form.bio}
              onChange={(e) => setForm({ ...form, bio: e.target.value })}
              className="w-full p-3 text-sm border border-slate-300 rounded-lg"
            />
          </div>

          {/* Transactional Email Alert Toggle */}
          <div className="p-4 rounded-xl border border-slate-200 bg-[#F8FAFC] flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <Bell className="w-5 h-5 text-[#1D4ED8] shrink-0 mt-0.5" />
              <div>
                <div className="text-sm font-semibold text-[#0F172A]">
                  Transactional Email Notifications
                </div>
                <p className="text-xs text-slate-600 mt-0.5">
                  Send automated email alerts for registration confirmation, password reset
                  requests, and completed interview score summaries.
                </p>
              </div>
            </div>
            <label className="inline-flex items-center cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={form.emailAlertsEnabled}
                onChange={(e) => setForm({ ...form, emailAlertsEnabled: e.target.checked })}
                className="w-4 h-4 accent-[#1D4ED8] rounded"
              />
              <span className="ml-2 text-xs font-semibold text-slate-700">
                {form.emailAlertsEnabled ? 'Enabled' : 'Paused'}
              </span>
            </label>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg cursor-pointer disabled:opacity-60"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Save Changes
            </button>
          </div>
        </form>
      </div>

      {/* Email Notification History */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center gap-2">
          <Mail className="w-4 h-4 text-[#1D4ED8]" />
          <h3 className="font-display text-base font-semibold text-[#0F172A]">
            Recent Email Notification Activity
          </h3>
        </div>

        {loadingLogs ? (
          <div className="p-8 text-center">
            <Loader2 className="w-5 h-5 animate-spin text-[#1D4ED8] mx-auto" />
          </div>
        ) : logs.length === 0 ? (
          <div className="p-6 text-sm text-slate-500">
            No transactional emails logged yet for this account.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-6">Timestamp</th>
                  <th className="py-3 px-4">Event</th>
                  <th className="py-3 px-4">Subject</th>
                  <th className="py-3 px-6 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {logs.map((log) => (
                  <tr key={log.id}>
                    <td className="py-3 px-6 text-xs text-slate-500 tabular-nums whitespace-nowrap">
                      {new Date(log.sentAt).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-xs font-medium text-[#0F172A] capitalize">
                      {log.eventType.replace('_', ' ')}
                    </td>
                    <td className="py-3 px-4 text-slate-700">{log.subject}</td>
                    <td className="py-3 px-6 text-right text-xs font-mono font-semibold text-slate-700 capitalize whitespace-nowrap">
                      {log.deliveryStatus === 'sent'
                        ? `Sent (${log.provider})`
                        : log.deliveryStatus === 'logged'
                        ? 'Recorded'
                        : 'Failed'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
