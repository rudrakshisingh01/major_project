import React from 'react';
import {
  ArrowRight,
  BarChart3,
  BookOpen,
  CheckCircle2,
  Compass,
  Download,
  Layers,
  ShieldCheck,
  Sliders,
} from 'lucide-react';
import { downloadProjectSourceZip } from '../lib/downloadZip';

interface LandingPageProps {
  onNavigateAuth: (mode: 'login' | 'register') => void;
}

export function LandingPage({ onNavigateAuth }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] flex flex-col">
      {/* Strict 3-Zone Top Navigation Bar */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <a
            href="#top"
            className="font-display text-xl font-bold tracking-tight text-[#0F172A] whitespace-nowrap shrink-0"
          >
            InterviewIQ
          </a>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
            <a
              href="#features"
              className="hover:text-[#1D4ED8] transition-colors whitespace-nowrap shrink-0"
            >
              Features
            </a>
            <a
              href="#adaptive-engine"
              className="hover:text-[#1D4ED8] transition-colors whitespace-nowrap shrink-0"
            >
              Adaptive Engine
            </a>
            <a
              href="#how-it-works"
              className="hover:text-[#1D4ED8] transition-colors whitespace-nowrap shrink-0"
            >
              How It Works
            </a>
            <a
              href="#benefits"
              className="hover:text-[#1D4ED8] transition-colors whitespace-nowrap shrink-0"
            >
              Benefits
            </a>
            <button
              type="button"
              onClick={() => onNavigateAuth('login')}
              className="hover:text-[#1D4ED8] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Login
            </button>
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => onNavigateAuth('register')}
              className="px-4 py-2 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Get Started
            </button>
          </div>
        </div>
      </header>

      <main id="top" className="flex-1">
        {/* Hero Split Section */}
        <section className="max-w-7xl mx-auto px-6 pt-12 pb-16 lg:pt-16 lg:pb-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
            <div className="lg:col-span-7 flex flex-col justify-center">
              <p className="text-sm font-medium text-[#1D4ED8] mb-4">
                Smart Interview Management · Adaptive Assessment · Performance Analytics
              </p>
              <h1 className="font-display text-4xl sm:text-5xl lg:text-[3.5rem] font-bold tracking-tight text-[#0F172A] leading-[1.08] text-balance">
                Practice Smarter. Perform Better. Get Hired.
              </h1>
              <p className="mt-6 text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
                InterviewIQ combines a structured technical and behavioral question bank with a
                real-time adaptive difficulty engine, transparent rule-based answer evaluation,
                and longitudinal topic mastery analytics designed for graduating Computer Science
                candidates.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => onNavigateAuth('register')}
                  className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Get Started
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onNavigateAuth('login')}
                  className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-[#0F172A] bg-white border border-slate-300 hover:border-slate-400 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Login to Account
                </button>
              </div>
            </div>

            <div className="lg:col-span-5 flex">
              <div className="relative w-full min-h-[280px] lg:min-h-[380px] rounded-2xl overflow-hidden border border-slate-200 bg-gradient-to-br from-[#0F172A] to-[#1E3A8A]">
                <img
                  src="/src/assets/images/hero_interview_studio_1795148050357.jpg"
                  alt="Computer science student preparing for a technical interview on a laptop"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover lg:h-full"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A]/75 via-[#0F172A]/15 to-transparent" />
                <div className="absolute bottom-5 left-5 right-5 text-white">
                  <p className="text-xs font-medium text-slate-200">
                    Adaptive Mock Assessment Workspace
                  </p>
                  <p className="text-base font-semibold mt-1">
                    Role-calibrated Technical &amp; HR evaluations across 12 CS domains
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* 4-Column Quantitative Strip Directly Below Hero Split */}
          <div className="mt-12 grid grid-cols-2 lg:grid-cols-4 gap-4 border-t border-slate-200 pt-8">
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="font-mono text-2xl font-semibold text-[#0F172A] tabular-nums">
                65+
              </div>
              <div className="text-sm text-slate-600 mt-1">
                Curated Questions Across 12 Core CS &amp; HR Topics
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="font-mono text-2xl font-semibold text-[#1D4ED8] tabular-nums">
                8 Roles
              </div>
              <div className="text-sm text-slate-600 mt-1">
                Frontend, Backend, Full Stack, Java, Python, C++, Data, SWE
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="font-mono text-2xl font-semibold text-[#6D28D9] tabular-nums">
                3 Tiers
              </div>
              <div className="text-sm text-slate-600 mt-1">
                Dynamic Beginner, Intermediate &amp; Advanced Calibration
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="font-mono text-2xl font-semibold text-[#0F172A] tabular-nums">
                4 Metrics
              </div>
              <div className="text-sm text-slate-600 mt-1">
                Keyword Relevance, Conceptual Depth, Completeness &amp; Fit
              </div>
            </div>
          </div>
        </section>

        {/* Features Asymmetric Grid */}
        <section id="features" className="bg-white border-y border-slate-200 py-16 lg:py-20">
          <div className="max-w-7xl mx-auto px-6">
            <div className="max-w-2xl">
              <p className="text-sm font-medium text-[#1D4ED8]">Platform Capabilities</p>
              <h2 className="font-display text-3xl font-bold text-[#0F172A] mt-2 text-balance">
                Built around measurable interview readiness
              </h2>
              <p className="text-slate-600 mt-3 leading-relaxed">
                Every session records granular question-level scores, response durations, and
                concept coverage in PostgreSQL so your preparation focuses strictly on what
                moves your readiness forward.
              </p>
            </div>

            <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2 bg-[#F8FAFC] border border-slate-200 rounded-xl p-7">
                <div className="w-10 h-10 rounded-lg bg-[#1D4ED8]/10 text-[#1D4ED8] flex items-center justify-center">
                  <Sliders className="w-5 h-5" />
                </div>
                <h3 className="font-display text-xl font-semibold text-[#0F172A] mt-5">
                  Smart Adaptive Question Selection
                </h3>
                <p className="text-sm text-slate-600 mt-2 leading-relaxed max-w-xl">
                  Rather than serving a static quiz, InterviewIQ evaluates each answer immediately
                  and adjusts the next question’s difficulty tier—escalating at 80%+ mastery,
                  stabilizing between 40–79%, and reinforcing fundamentals below 40% without ever
                  repeating questions.
                </p>
              </div>

              <div className="bg-[#F8FAFC] border border-slate-200 rounded-xl p-7">
                <div className="w-10 h-10 rounded-lg bg-[#6D28D9]/10 text-[#6D28D9] flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <h3 className="font-display text-xl font-semibold text-[#0F172A] mt-5">
                  Transparent Rubric Scoring
                </h3>
                <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                  Rule-based evaluation breaks down every response out of 10 marks, surfacing
                  matched keywords, missing key concepts, and the model reference answer.
                </p>
              </div>

              <div className="bg-[#F8FAFC] border border-slate-200 rounded-xl p-7">
                <div className="w-10 h-10 rounded-lg bg-[#0F172A]/10 text-[#0F172A] flex items-center justify-center">
                  <BookOpen className="w-5 h-5" />
                </div>
                <h3 className="font-display text-xl font-semibold text-[#0F172A] mt-5">
                  Searchable Question Bank
                </h3>
                <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                  Explore 65+ Technical and HR questions across DSA, OS, DBMS, Networks, OOP,
                  Java, C++, Python, React, and Node.js—or add custom practice prompts.
                </p>
              </div>

              <div className="md:col-span-2 bg-[#F8FAFC] border border-slate-200 rounded-xl p-7">
                <div className="w-10 h-10 rounded-lg bg-[#1D4ED8]/10 text-[#1D4ED8] flex items-center justify-center">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <h3 className="font-display text-xl font-semibold text-[#0F172A] mt-5">
                  Longitudinal Performance Tracking &amp; PDF Reports
                </h3>
                <p className="text-sm text-slate-600 mt-2 leading-relaxed max-w-xl">
                  Compare Technical versus HR accuracy, monitor time spent per difficulty tier,
                  identify weak topics automatically, and export structured PDF reports for
                  faculty review or placement mentoring.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Adaptive Engine Showcase */}
        <section id="adaptive-engine" className="max-w-7xl mx-auto px-6 py-16 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-6">
              <div className="rounded-2xl overflow-hidden border border-slate-200 bg-white">
                <img
                  src="/src/assets/images/adaptive_assessment_diagram_1795148050883.jpg"
                  alt="Isometric diagram illustrating ascending adaptive interview difficulty tiers"
                  referrerPolicy="no-referrer"
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>

            <div className="lg:col-span-6">
              <p className="text-sm font-medium text-[#6D28D9]">Core Research Contribution</p>
              <h2 className="font-display text-3xl font-bold text-[#0F172A] mt-2 text-balance">
                Real-time difficulty calibration on every question
              </h2>
              <p className="text-slate-600 mt-3 leading-relaxed">
                Standard mock tests waste time asking trivial questions to strong candidates or
                overwhelming beginners. InterviewIQ tracks performance continuously after every
                submission:
              </p>

              <div className="mt-6 space-y-4 border-t border-slate-200 pt-6">
                <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-200">
                  <div>
                    <div className="font-semibold text-[#0F172A]">80% – 100% Score</div>
                    <div className="text-sm text-slate-600 mt-0.5">
                      Promotes the next question to a higher difficulty tier up to Advanced.
                    </div>
                  </div>
                  <span className="font-mono text-xs font-semibold text-emerald-700 whitespace-nowrap shrink-0">
                    Level Up
                  </span>
                </div>

                <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-200">
                  <div>
                    <div className="font-semibold text-[#0F172A]">40% – 79% Score</div>
                    <div className="text-sm text-slate-600 mt-0.5">
                      Maintains the current difficulty tier while rotating uncovered topics.
                    </div>
                  </div>
                  <span className="font-mono text-xs font-semibold text-[#1D4ED8] whitespace-nowrap shrink-0">
                    Maintain
                  </span>
                </div>

                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="font-semibold text-[#0F172A]">Below 40% Score</div>
                    <div className="text-sm text-slate-600 mt-0.5">
                      Steps down one tier (bounded at Beginner) to solidify core concepts.
                    </div>
                  </div>
                  <span className="font-mono text-xs font-semibold text-amber-700 whitespace-nowrap shrink-0">
                    Reinforce
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section id="how-it-works" className="bg-[#0F172A] text-white py-16 lg:py-20">
          <div className="max-w-7xl mx-auto px-6">
            <div className="max-w-2xl">
              <p className="text-sm font-medium text-blue-300">Structured Workflow</p>
              <h2 className="font-display text-3xl font-bold mt-2 text-balance">
                How InterviewIQ guides you from setup to placement readiness
              </h2>
            </div>

            <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  step: '01. Configure Session',
                  desc: 'Select your target job role, Technical/HR/Mixed track, starting difficulty, question count, and timer.',
                },
                {
                  step: '02. Adaptive Assessment',
                  desc: 'Answer one question at a time with live countdown, auto-saved drafts, and instant difficulty adaptation.',
                },
                {
                  step: '03. Concept Feedback',
                  desc: 'Inspect your score out of 10, matched rubric keywords, missing concepts, and the reference model answer.',
                },
                {
                  step: '04. Track & Improve',
                  desc: 'Analyze multi-attempt charts, receive weak-topic practice suggestions, and download full PDF reports.',
                },
              ].map((item) => (
                <div
                  key={item.step}
                  className="bg-slate-900/70 border border-slate-800 rounded-xl p-6"
                >
                  <div className="font-display text-lg font-semibold text-white">
                    {item.step}
                  </div>
                  <p className="text-sm text-slate-300 mt-2.5 leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section id="benefits" className="max-w-7xl mx-auto px-6 py-16 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-5">
              <p className="text-sm font-medium text-[#1D4ED8]">Why InterviewIQ</p>
              <h2 className="font-display text-3xl font-bold text-[#0F172A] mt-2 text-balance">
                Engineered for campus placements and technical evaluations
              </h2>
              <p className="text-slate-600 mt-3 leading-relaxed">
                Designed specifically for Computer Science students preparing for software
                engineering, full-stack, backend, and data analytics interviews.
              </p>
              <button
                type="button"
                onClick={() => onNavigateAuth('register')}
                className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Create Free Student Account
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="bg-white border border-slate-200 rounded-xl p-6">
                <Compass className="w-5 h-5 text-[#1D4ED8]" />
                <h3 className="font-display text-base font-semibold text-[#0F172A] mt-3">
                  Targeted Weak-Topic Drills
                </h3>
                <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
                  Rule-based recommendations identify low-scoring topics and surface matching
                  questions immediately.
                </p>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl p-6">
                <Layers className="w-5 h-5 text-[#6D28D9]" />
                <h3 className="font-display text-base font-semibold text-[#0F172A] mt-3">
                  Full Session Isolation
                </h3>
                <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
                  Every student maintains private interview histories, performance records, and
                  custom question banks in PostgreSQL.
                </p>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl p-6">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="font-display text-base font-semibold text-[#0F172A] mt-3">
                  Transactional Email Alerts
                </h3>
                <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
                  Receive automatic notifications on account registration, password resets, and
                  completed interview summaries.
                </p>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl p-6">
                <BarChart3 className="w-5 h-5 text-[#1D4ED8]" />
                <h3 className="font-display text-base font-semibold text-[#0F172A] mt-3">
                  Time Management Insights
                </h3>
                <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
                  Measure average response duration per question and difficulty tier alongside
                  accuracy percentages.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Quiet Footer */}
      <footer className="bg-white border-t border-slate-200 py-8">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-sm text-slate-500">
          <div>
            <span className="font-display font-semibold text-[#0F172A]">InterviewIQ</span>
            <span className="mx-2">·</span>
            <span>
              B.Tech Computer Science Major Project — Smart Interview Management &amp; Adaptive
              Assessment
            </span>
          </div>
          <div className="flex items-center gap-6">
            <button
              type="button"
              onClick={() => downloadProjectSourceZip().catch(() => {})}
              className="inline-flex items-center gap-1.5 text-[#1D4ED8] font-medium hover:underline cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Download Source (.zip)
            </button>
            <button
              type="button"
              onClick={() => onNavigateAuth('login')}
              className="hover:text-[#0F172A] transition-colors cursor-pointer"
            >
              Login
            </button>
            <button
              type="button"
              onClick={() => onNavigateAuth('register')}
              className="hover:text-[#0F172A] transition-colors cursor-pointer"
            >
              Register
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
