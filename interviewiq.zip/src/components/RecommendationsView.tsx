import React, { useEffect, useState } from 'react';
import { ArrowRight, Compass, Loader2, TrendingDown, TrendingUp } from 'lucide-react';
import { apiRequest } from '../lib/api';
import { AppRoute } from './AppLayout';

interface RecommendationsData {
  suggestedDifficulty: string;
  overallReadinessLevel: string;
  scoreTrendDelta: number | null;
  preparationSummary: string;
  weakTopics: Array<{
    topic: string;
    averageScore: number;
    accuracyPercentage: number;
    attempts: number;
    priority: string;
    recommendedDifficulty: string;
    reason: string;
  }>;
  strongTopics: Array<{
    topic: string;
    averageScore: number;
    accuracyPercentage: number;
    attempts: number;
    recommendedDifficulty: string;
    reason: string;
  }>;
  recommendedQuestions: Array<{
    id: number;
    questionCode: string;
    questionText: string;
    topic: string;
    difficulty: string;
    jobRole: string;
  }>;
}

export function RecommendationsView({ onNavigate }: { onNavigate: (route: AppRoute) => void }) {
  const [data, setData] = useState<RecommendationsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    apiRequest<{ recommendations: RecommendationsData }>('/api/recommendations')
      .then((res) => {
        if (active) setData(res.recommendations);
      })
      .catch((err: any) => {
        if (active) setError(err.message || 'Failed to load recommendations.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
        <Loader2 className="w-6 h-6 animate-spin text-[#1D4ED8] mx-auto" />
        <p className="text-sm text-slate-600 mt-3">Analyzing your interview records...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="bg-white border border-red-200 rounded-xl p-6 text-sm text-red-700">
        {error || 'Unable to generate recommendations.'}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Preparation Summary Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#1D4ED8]">
              <Compass className="w-4 h-4" />
              Rule-Based Preparation Advisor
            </div>
            <h2 className="font-display text-2xl font-bold text-[#0F172A]">
              Readiness Level: {data.overallReadinessLevel}
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">{data.preparationSummary}</p>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap gap-4 shrink-0">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 min-w-[150px]">
              <div className="text-xs text-slate-500">Suggested Difficulty</div>
              <div className="font-display text-lg font-bold text-[#1D4ED8] mt-1">
                {data.suggestedDifficulty}
              </div>
            </div>
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 min-w-[150px]">
              <div className="text-xs text-slate-500">Attempt Trend</div>
              <div className="font-mono text-lg font-bold mt-1 flex items-center gap-1.5 tabular-nums">
                {data.scoreTrendDelta === null ? (
                  <span className="text-slate-500">—</span>
                ) : data.scoreTrendDelta >= 0 ? (
                  <span className="text-emerald-700 flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" />+{data.scoreTrendDelta}%
                  </span>
                ) : (
                  <span className="text-amber-700 flex items-center gap-1">
                    <TrendingDown className="w-4 h-4" />
                    {data.scoreTrendDelta}%
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Weak vs Strong Topics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="font-display text-lg font-semibold text-[#0F172A] mb-4">
            Priority Topics for Improvement
          </h3>
          {data.weakTopics.length > 0 ? (
            <div className="space-y-3">
              {data.weakTopics.map((wt) => (
                <div
                  key={wt.topic}
                  className="p-4 rounded-xl border border-slate-200 bg-[#F8FAFC] space-y-1.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-sm text-[#0F172A]">{wt.topic}</span>
                    <span className="font-mono text-xs font-semibold text-amber-700 tabular-nums">
                      {wt.priority} Priority · {wt.averageScore}/10
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{wt.reason}</p>
                  <div className="text-xs text-[#1D4ED8] font-medium">
                    Recommended Level: {wt.recommendedDifficulty}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-500 py-4">
              No low-scoring topics flagged. Complete more Technical or Mixed interviews to surface
              granular subject gaps.
            </p>
          )}
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="font-display text-lg font-semibold text-[#0F172A] mb-4">
            Verified Strong Topics
          </h3>
          {data.strongTopics.length > 0 ? (
            <div className="space-y-3">
              {data.strongTopics.map((st) => (
                <div
                  key={st.topic}
                  className="p-4 rounded-xl border border-slate-200 bg-emerald-50/30 space-y-1.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-sm text-[#0F172A]">{st.topic}</span>
                    <span className="font-mono text-xs font-semibold text-emerald-700 tabular-nums">
                      {st.averageScore}/10 · {st.accuracyPercentage}% Acc
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{st.reason}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-500 py-4">
              Topics averaging 6.5/10 or higher will appear here as verified strengths.
            </p>
          )}
        </div>
      </div>

      {/* Recommended Practice Questions */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div>
            <h3 className="font-display text-lg font-semibold text-[#0F172A]">
              Recommended Practice Questions
            </h3>
            <p className="text-xs text-slate-500">
              Targeted prompts aligned with your weak topics and {data.suggestedDifficulty} tier
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('setup')}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg cursor-pointer whitespace-nowrap shrink-0"
          >
            Practice Now
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-slate-200">
          {data.recommendedQuestions.map((q) => (
            <div key={q.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="text-xs text-slate-500">
                  <span className="font-mono font-semibold text-slate-700">{q.questionCode}</span>
                  <span className="mx-1.5">·</span>
                  <span>{q.topic}</span>
                  <span className="mx-1.5">·</span>
                  <span className="font-medium text-[#1D4ED8]">{q.difficulty}</span>
                </div>
                <div className="text-sm font-medium text-[#0F172A] mt-1">{q.questionText}</div>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('questions')}
                className="text-xs font-semibold text-[#1D4ED8] hover:underline whitespace-nowrap shrink-0 cursor-pointer"
              >
                Inspect Answer Key
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
