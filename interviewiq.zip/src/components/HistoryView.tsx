import React, { useEffect, useState } from 'react';
import { History, Loader2, Trash2 } from 'lucide-react';
import { apiRequest } from '../lib/api';
import { useToast } from '../context/ToastContext';
import { AppRoute } from './AppLayout';

interface InterviewHistoryItem {
  id: number;
  jobRole: string;
  category: string;
  initialDifficulty: string;
  currentDifficulty: string;
  totalQuestions: number;
  answeredCount: number;
  totalScore: number;
  maxScore: number;
  percentage: number;
  durationSeconds: number;
  status: string;
  startedAt: string;
  completedAt: string | null;
}

interface HistoryViewProps {
  onOpenInterview: (interviewId: number, status: string) => void;
  onNavigate: (route: AppRoute) => void;
}

export function HistoryView({ onOpenInterview, onNavigate }: HistoryViewProps) {
  const { showToast } = useToast();
  const [items, setItems] = useState<InterviewHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    apiRequest<{ interviews: InterviewHistoryItem[] }>('/api/interviews')
      .then((res) => {
        if (active) setItems(res.interviews);
      })
      .catch((err: any) => {
        showToast(err.message || 'Failed to load interview history.', 'error');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [showToast]);

  const handleDelete = async (id: number) => {
    try {
      await apiRequest(`/api/interviews/${id}`, { method: 'DELETE' });
      setItems((prev) => prev.filter((item) => item.id !== id));
      showToast('Interview record deleted.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to delete interview.', 'error');
    }
  };

  if (loading) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
        <Loader2 className="w-6 h-6 animate-spin text-[#1D4ED8] mx-auto" />
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div className="px-6 py-5 border-b border-slate-200 flex items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-bold text-[#0F172A]">Interview History</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            All mock interview attempts and detailed evaluation reports
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('setup')}
          className="px-4 py-2 text-sm font-semibold text-white bg-[#1D4ED8] hover:bg-[#1E40AF] rounded-lg cursor-pointer whitespace-nowrap shrink-0"
        >
          New Interview
        </button>
      </div>

      {items.length === 0 ? (
        <div className="p-12 text-center">
          <History className="w-9 h-9 text-slate-300 mx-auto" />
          <p className="text-sm font-medium text-slate-700 mt-3">No interviews attempted yet</p>
          <p className="text-xs text-slate-500 mt-1">
            Configure your first adaptive assessment to record your history here.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                <th className="py-3.5 px-6">Date</th>
                <th className="py-3.5 px-4">Job Role</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4">Difficulty</th>
                <th className="py-3.5 px-4 text-right">Score</th>
                <th className="py-3.5 px-4 text-right">Duration</th>
                <th className="py-3.5 px-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {items.map((item) => {
                const mins = Math.floor(item.durationSeconds / 60);
                const secs = item.durationSeconds % 60;
                return (
                  <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-6 text-slate-600 tabular-nums whitespace-nowrap">
                      {new Date(item.startedAt).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                      })}
                    </td>
                    <td className="py-3.5 px-4 font-medium text-[#0F172A]">{item.jobRole}</td>
                    <td className="py-3.5 px-4 text-slate-600">{item.category}</td>
                    <td className="py-3.5 px-4 text-slate-600 whitespace-nowrap">
                      {item.initialDifficulty} → {item.currentDifficulty}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-semibold text-[#0F172A] tabular-nums whitespace-nowrap">
                      {item.status === 'completed'
                        ? `${item.totalScore.toFixed(1)}/${item.maxScore} (${item.percentage.toFixed(
                            1
                          )}%)`
                        : `${item.answeredCount}/${item.totalQuestions} Qs`}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-slate-600 tabular-nums whitespace-nowrap">
                      {item.status === 'completed' ? `${mins}m ${secs}s` : 'In Progress'}
                    </td>
                    <td className="py-3.5 px-6 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => onOpenInterview(item.id, item.status)}
                          className="text-xs font-semibold text-[#1D4ED8] hover:underline cursor-pointer"
                        >
                          {item.status === 'completed' ? 'View Report' : 'Resume'}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(item.id)}
                          className="text-slate-400 hover:text-red-600 transition-colors cursor-pointer"
                          aria-label="Delete interview"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
