import React, { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { LandingPage } from './components/LandingPage';
import { AuthPages } from './components/AuthPages';
import { AppLayout, AppRoute } from './components/AppLayout';
import { DashboardView } from './components/DashboardView';
import { InterviewSetupView } from './components/InterviewSetupView';
import { LiveInterviewView } from './components/LiveInterviewView';
import { InterviewReportView } from './components/InterviewReportView';
import { QuestionBankView } from './components/QuestionBankView';
import { AnalyticsView } from './components/AnalyticsView';
import { RecommendationsView } from './components/RecommendationsView';
import { HistoryView } from './components/HistoryView';
import { ProfileView } from './components/ProfileView';

const ROUTE_TITLES: Record<AppRoute, string> = {
  dashboard: 'Student Dashboard',
  setup: 'Interview Setup',
  live: 'Adaptive Assessment Session',
  report: 'Interview Report',
  questions: 'Question Bank',
  analytics: 'Performance Tracking',
  recommendations: 'Personalized Recommendations',
  history: 'Interview History',
  profile: 'Profile & Email Alerts',
};

function AppRouter() {
  const { user, loading } = useAuth();
  const [publicScreen, setPublicScreen] = useState<'landing' | 'login' | 'register'>('landing');
  const [route, setRoute] = useState<AppRoute>('dashboard');
  const [activeInterviewId, setActiveInterviewId] = useState<number | null>(null);
  const [initialInterviewPayload, setInitialInterviewPayload] = useState<any>(null);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-7 h-7 animate-spin text-[#1D4ED8] mx-auto" />
          <p className="text-sm text-slate-600 mt-3">Initializing InterviewIQ...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    if (publicScreen === 'landing') {
      return <LandingPage onNavigateAuth={(mode) => setPublicScreen(mode)} />;
    }
    return (
      <AuthPages
        initialMode={publicScreen}
        onBackToLanding={() => setPublicScreen('landing')}
      />
    );
  }

  const handleOpenInterview = (interviewId: number, status: string) => {
    setInitialInterviewPayload(null);
    setActiveInterviewId(interviewId);
    setRoute(status === 'completed' ? 'report' : 'live');
  };

  const handleInterviewStarted = (payload: any) => {
    setInitialInterviewPayload(payload);
    setActiveInterviewId(payload.interview.id);
    setRoute('live');
  };

  const handleInterviewCompleted = (interviewId: number) => {
    setInitialInterviewPayload(null);
    setActiveInterviewId(interviewId);
    setRoute('report');
  };

  return (
    <AppLayout
      currentRoute={route}
      onNavigate={(nextRoute) => {
        setRoute(nextRoute);
      }}
      pageTitle={ROUTE_TITLES[route]}
    >
      {route === 'dashboard' && (
        <DashboardView
          onNavigate={setRoute}
          onOpenInterview={handleOpenInterview}
        />
      )}

      {route === 'setup' && (
        <InterviewSetupView onInterviewStarted={handleInterviewStarted} />
      )}

      {route === 'live' && activeInterviewId && (
        <LiveInterviewView
          interviewId={activeInterviewId}
          initialData={initialInterviewPayload ?? undefined}
          onInterviewCompleted={handleInterviewCompleted}
        />
      )}

      {route === 'report' && activeInterviewId && (
        <InterviewReportView
          interviewId={activeInterviewId}
          onBack={() => setRoute('history')}
        />
      )}

      {route === 'questions' && <QuestionBankView />}

      {route === 'analytics' && <AnalyticsView onNavigate={setRoute} />}

      {route === 'recommendations' && <RecommendationsView onNavigate={setRoute} />}

      {route === 'history' && (
        <HistoryView
          onOpenInterview={handleOpenInterview}
          onNavigate={setRoute}
        />
      )}

      {route === 'profile' && <ProfileView />}
    </AppLayout>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <AppRouter />
      </AuthProvider>
    </ToastProvider>
  );
}
