import { ScoreBreakdown } from '../db/schema.ts';

export interface EvaluationInput {
  questionText: string;
  topic: string;
  difficulty: string;
  expectedAnswer: string;
  evaluationKeywords: string[];
  evaluationCriteria: string;
  userAnswer: string;
  maxMarks?: number;
}

export interface EvaluationResult {
  score: number;
  maxMarks: number;
  percentage: number;
  correctnessLevel:
    | 'Excellent'
    | 'Good'
    | 'Partial'
    | 'Needs Improvement'
    | 'Empty / Irrelevant';
  feedback: string;
  matchedKeywords: string[];
  missingConcepts: string[];
  suggestedImprovements: string;
  expectedAnswer: string;
  scoreBreakdown: ScoreBreakdown;
  evaluationMode: 'rule-based-v1';
}

export interface AnswerEvaluator {
  evaluate(input: EvaluationInput): Promise<EvaluationResult>;
}

const STOPWORDS = new Set([
  'the', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had',
  'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'can',
  'a', 'an', 'and', 'or', 'but', 'if', 'then', 'else', 'when', 'at', 'from',
  'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 'during',
  'before', 'after', 'above', 'below', 'to', 'of', 'in', 'on', 'off', 'over',
  'under', 'again', 'further', 'once', 'here', 'there', 'all', 'any', 'both',
  'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not',
  'only', 'own', 'same', 'so', 'than', 'too', 'very', 'just', 'that', 'this',
  'these', 'those', 'what', 'which', 'who', 'whom', 'why', 'how', 'it', 'its',
  'they', 'them', 'their', 'we', 'our', 'you', 'your', 'he', 'she', 'use', 'used',
  'using', 'make', 'makes', 'also', 'well', 'one', 'two', 'such', 'like',
]);

const REASONING_MARKERS = [
  'because', 'therefore', 'however', 'whereas', 'while', 'although', 'since',
  'allows', 'prevents', 'ensures', 'causes', 'reduces', 'improves', 'requires',
  'trade-off', 'tradeoff', 'advantage', 'disadvantage', 'example', 'for instance',
  'complexity', 'overhead', 'memory', 'performance', 'time', 'space',
];

function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s+()#*/.-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function tokenize(text: string): string[] {
  return normalizeText(text)
    .split(/\s+/)
    .filter((token) => token.length > 1 && !STOPWORDS.has(token));
}

function keywordMatches(normalizedAnswer: string, answerTokens: Set<string>, keyword: string): boolean {
  const normKw = normalizeText(keyword);
  if (!normKw) return false;

  // Direct substring match for phrases or complexity notations like O(log n), C++, *args
  if (normalizedAnswer.includes(normKw)) {
    return true;
  }

  // Stem/token overlap for multi-word keywords
  const kwParts = normKw.split(/\s+/).filter((p) => p.length > 2 && !STOPWORDS.has(p));
  if (kwParts.length === 0) return false;

  let hits = 0;
  for (const part of kwParts) {
    const stem = part.length > 5 ? part.slice(0, part.length - 2) : part;
    for (const token of answerTokens) {
      if (token === part || (stem.length >= 4 && token.startsWith(stem))) {
        hits++;
        break;
      }
    }
  }

  return hits === kwParts.length || (kwParts.length >= 2 && hits / kwParts.length >= 0.75);
}

function isGibberishOrEmpty(answer: string): boolean {
  const trimmed = answer.trim();
  if (trimmed.length < 12) return true;

  const words = trimmed.split(/\s+/).filter((w) => /[a-zA-Z0-9]/.test(w));
  if (words.length < 3) return true;

  // Detect repetitive filler like "asdfasdf asdfasdf" or "aaaa bbbb cccc"
  const uniqueWords = new Set(words.map((w) => w.toLowerCase()));
  if (uniqueWords.size <= 2 && words.length >= 5) return true;

  // Detect keyboard mash (no vowels in majority of words)
  const realLookingWords = words.filter((w) => /[aeiouyAEIOUY]/.test(w) || /\d/.test(w));
  if (realLookingWords.length / words.length < 0.4) return true;

  return false;
}

export class RuleBasedAnswerEvaluator implements AnswerEvaluator {
  async evaluate(input: EvaluationInput): Promise<EvaluationResult> {
    const maxMarks = input.maxMarks ?? 10;
    const rawAnswer = (input.userAnswer || '').trim();

    if (isGibberishOrEmpty(rawAnswer)) {
      return {
        score: 0,
        maxMarks,
        percentage: 0,
        correctnessLevel: 'Empty / Irrelevant',
        feedback:
          'Your response is either empty, too brief, or lacks meaningful technical/behavioral content. Provide a structured explanation addressing the core concepts.',
        matchedKeywords: [],
        missingConcepts: input.evaluationKeywords.slice(0, 6),
        suggestedImprovements: `Review the prompt carefully and explain key concepts such as: ${input.evaluationKeywords
          .slice(0, 4)
          .join(', ')}.`,
        expectedAnswer: input.expectedAnswer,
        scoreBreakdown: {
          keywordRelevance: 0,
          conceptualUnderstanding: 0,
          completeness: 0,
          relevance: 0,
        },
        evaluationMode: 'rule-based-v1',
      };
    }

    const normalizedAnswer = normalizeText(rawAnswer);
    const answerTokens = new Set(tokenize(rawAnswer));
    const questionTokens = new Set(tokenize(input.questionText));
    const expectedTokens = new Set(tokenize(input.expectedAnswer));

    // Check if user merely echoed the question text
    let newTokensNotInQuestion = 0;
    for (const token of answerTokens) {
      if (!questionTokens.has(token)) {
        newTokensNotInQuestion++;
      }
    }

    if (answerTokens.size > 0 && newTokensNotInQuestion / answerTokens.size < 0.22) {
      return {
        score: 0.5,
        maxMarks,
        percentage: 5,
        correctnessLevel: 'Empty / Irrelevant',
        feedback:
          'Your answer mostly repeats words from the question without introducing explanatory details or solutions.',
        matchedKeywords: [],
        missingConcepts: input.evaluationKeywords.slice(0, 6),
        suggestedImprovements: `Go beyond restating the prompt. Explain the underlying mechanism using terms like ${input.evaluationKeywords
          .slice(0, 4)
          .join(', ')}.`,
        expectedAnswer: input.expectedAnswer,
        scoreBreakdown: {
          keywordRelevance: 0,
          conceptualUnderstanding: 0,
          completeness: 0.3,
          relevance: 0.2,
        },
        evaluationMode: 'rule-based-v1',
      };
    }

    // 1. Keyword Relevance (0 - 4.0 marks)
    const matchedKeywords: string[] = [];
    const missingConcepts: string[] = [];

    for (const kw of input.evaluationKeywords) {
      if (keywordMatches(normalizedAnswer, answerTokens, kw)) {
        matchedKeywords.push(kw);
      } else {
        missingConcepts.push(kw);
      }
    }

    const totalKeywords = Math.max(input.evaluationKeywords.length, 1);
    const keywordRatio = matchedKeywords.length / totalKeywords;
    // Full keyword score achievable at >= 65% of keyword checklist matched cleanly
    const normalizedKwScore = Math.min(1, keywordRatio / 0.65);
    const keywordRelevance = Number((normalizedKwScore * 4.0).toFixed(2));

    // 2. Conceptual Understanding (0 - 2.5 marks)
    // Overlap with expected answer domain vocabulary + explanatory reasoning markers
    let expectedHits = 0;
    for (const token of expectedTokens) {
      if (answerTokens.has(token)) expectedHits++;
    }
    const expectedVocabRatio = expectedTokens.size > 0 ? expectedHits / expectedTokens.size : 0;
    const vocabScore = Math.min(1, expectedVocabRatio / 0.45) * 1.6;

    let reasoningHits = 0;
    for (const marker of REASONING_MARKERS) {
      if (normalizedAnswer.includes(marker)) reasoningHits++;
    }
    const reasoningScore = Math.min(1, reasoningHits / 3) * 0.9;
    const conceptualUnderstanding = Number((vocabScore + reasoningScore).toFixed(2));

    // 3. Completeness & Depth (0 - 2.0 marks)
    const wordCount = rawAnswer.split(/\s+/).length;
    const targetWords =
      input.difficulty === 'Advanced' ? 55 : input.difficulty === 'Intermediate' ? 40 : 28;
    const lengthFactor = Math.min(1, wordCount / targetWords);
    const sentenceCount = rawAnswer.split(/[.!?\n]+/).filter((s) => s.trim().length > 6).length;
    const structureFactor = Math.min(1, sentenceCount / 3);
    const completeness = Number(((lengthFactor * 0.65 + structureFactor * 0.35) * 2.0).toFixed(2));

    // 4. Relevance to Question & Topic (0 - 1.5 marks)
    // Requires either matched keywords or expected/question topical alignment
    const hasTopicAnchor =
      matchedKeywords.length >= 1 || expectedVocabRatio >= 0.12 || newTokensNotInQuestion >= 6;
    let relevance = 0;
    if (hasTopicAnchor) {
      const anchorStrength = Math.min(
        1,
        keywordRatio * 0.8 + expectedVocabRatio * 0.7 + (newTokensNotInQuestion >= 10 ? 0.3 : 0.1)
      );
      relevance = Number((anchorStrength * 1.5).toFixed(2));
    }

    // If zero keywords matched AND very low expected overlap, cap score low as irrelevant
    let rawTotal = keywordRelevance + conceptualUnderstanding + completeness + relevance;
    if (matchedKeywords.length === 0 && expectedVocabRatio < 0.08) {
      rawTotal = Math.min(rawTotal, 2.0);
    }

    const score = Number(Math.min(maxMarks, Math.max(0, rawTotal)).toFixed(1));
    const percentage = Number(((score / maxMarks) * 100).toFixed(1));

    let correctnessLevel: EvaluationResult['correctnessLevel'] = 'Needs Improvement';
    if (percentage >= 80) correctnessLevel = 'Excellent';
    else if (percentage >= 60) correctnessLevel = 'Good';
    else if (percentage >= 40) correctnessLevel = 'Partial';
    else if (percentage < 10) correctnessLevel = 'Empty / Irrelevant';

    // Generate structured feedback
    let feedback = '';
    if (percentage >= 80) {
      feedback = `Strong, thorough answer covering ${matchedKeywords.length} key concepts (${matchedKeywords
        .slice(0, 4)
        .join(', ')}). Your explanation demonstrates solid conceptual clarity and depth.`;
    } else if (percentage >= 60) {
      feedback = `Good response capturing core ideas (${matchedKeywords
        .slice(0, 3)
        .join(', ') || 'general context'}). Adding a few sharper technical details or trade-offs will elevate this to an interview-ready answer.`;
    } else if (percentage >= 40) {
      feedback = `Partially correct answer. You touched on ${matchedKeywords.length} relevant point(s), but missed several critical concepts required by the evaluation rubric.`;
    } else {
      feedback = `Your answer lacks sufficient alignment with the core concepts expected for this ${input.difficulty.toLowerCase()} ${input.topic} question.`;
    }

    const topMissing = missingConcepts.slice(0, 5);
    const suggestedImprovements =
      topMissing.length > 0
        ? `Strengthen your answer by explicitly addressing: ${topMissing.join(', ')}. Rubric focus: ${input.evaluationCriteria}`
        : `Great coverage of core terms. Refine conciseness and include a concrete complexity or real-world trade-off example.`;

    return {
      score,
      maxMarks,
      percentage,
      correctnessLevel,
      feedback,
      matchedKeywords,
      missingConcepts,
      suggestedImprovements,
      expectedAnswer: input.expectedAnswer,
      scoreBreakdown: {
        keywordRelevance,
        conceptualUnderstanding,
        completeness,
        relevance,
      },
      evaluationMode: 'rule-based-v1',
    };
  }
}

export const answerEvaluator: AnswerEvaluator = new RuleBasedAnswerEvaluator();
