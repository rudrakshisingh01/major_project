import nodemailer from 'nodemailer';
import { db } from '../db/index.ts';
import { emailNotifications } from '../db/schema.ts';

export type EmailEventType = 'registration' | 'password_reset' | 'interview_completed';

interface DispatchResult {
  provider: 'resend' | 'smtp' | 'local_outbox';
  deliveryStatus: 'sent' | 'logged' | 'failed';
  providerMessageId?: string;
  errorMessage?: string;
}

function getAppBaseUrl(): string {
  return process.env.APP_URL || 'http://localhost:3000';
}

function getSenderAddress(): string {
  return process.env.EMAIL_FROM || 'InterviewIQ <notifications@interviewiq.edu>';
}

async function dispatchEmail(params: {
  to: string;
  subject: string;
  html: string;
  text: string;
}): Promise<DispatchResult> {
  const { to, subject, html, text } = params;
  const from = getSenderAddress();

  // 1. Try Resend transactional API if configured
  if (process.env.RESEND_API_KEY) {
    try {
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from,
          to: [to],
          subject,
          html,
          text,
        }),
      });

      const data = (await response.json()) as { id?: string; message?: string };
      if (!response.ok) {
        throw new Error(data.message || `Resend returned status ${response.status}`);
      }

      return {
        provider: 'resend',
        deliveryStatus: 'sent',
        providerMessageId: data.id,
      };
    } catch (err: any) {
      console.error('Resend dispatch failed:', err);
      return {
        provider: 'resend',
        deliveryStatus: 'failed',
        errorMessage: err?.message || 'Resend delivery failed',
      };
    }
  }

  // 2. Try Nodemailer SMTP if configured
  if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
    try {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT || 587),
        secure: Number(process.env.SMTP_PORT || 587) === 465,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      });

      const info = await transporter.sendMail({
        from,
        to,
        subject,
        text,
        html,
      });

      return {
        provider: 'smtp',
        deliveryStatus: 'sent',
        providerMessageId: info.messageId,
      };
    } catch (err: any) {
      console.error('SMTP dispatch failed:', err);
      return {
        provider: 'smtp',
        deliveryStatus: 'failed',
        errorMessage: err?.message || 'SMTP delivery failed',
      };
    }
  }

  // 3. Fallback: Record cleanly in database outbox when external SMTP/Resend secrets are not set
  return {
    provider: 'local_outbox',
    deliveryStatus: 'logged',
    providerMessageId: `outbox_${Date.now()}`,
  };
}

async function logEmailNotification(params: {
  userId?: number | null;
  userUid?: string | null;
  recipientEmail: string;
  eventType: EmailEventType;
  subject: string;
  result: DispatchResult;
}) {
  try {
    await db.insert(emailNotifications).values({
      userId: params.userId ?? null,
      userUid: params.userUid ?? null,
      recipientEmail: params.recipientEmail,
      eventType: params.eventType,
      subject: params.subject,
      provider: params.result.provider,
      deliveryStatus: params.result.deliveryStatus,
      providerMessageId: params.result.providerMessageId ?? null,
      errorMessage: params.result.errorMessage ?? null,
    });
  } catch (err) {
    console.error('Failed to record email notification log:', err);
  }
}

function wrapEmailLayout(title: string, bodyHtml: string): string {
  const appUrl = getAppBaseUrl();
  return `
  <div style="font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background-color: #f8fafc; padding: 32px 16px; color: #0f172a;">
    <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;">
      <div style="background: #0f172a; padding: 24px 28px; color: #ffffff;">
        <div style="font-size: 18px; font-weight: 700; letter-spacing: -0.02em;">InterviewIQ</div>
        <div style="font-size: 13px; color: #94a3b8; margin-top: 4px;">${title}</div>
      </div>
      <div style="padding: 28px; font-size: 15px; line-height: 1.6; color: #334155;">
        ${bodyHtml}
      </div>
      <div style="padding: 18px 28px; background: #f8fafc; border-top: 1px solid #e2e8f0; font-size: 12px; color: #64748b;">
        InterviewIQ Smart Interview Management & Adaptive Assessment · <a href="${appUrl}" style="color: #1d4ed8; text-decoration: none;">Open Platform</a>
      </div>
    </div>
  </div>`;
}

export async function sendRegistrationEmail(params: {
  userId: number;
  userUid: string;
  email: string;
  fullName: string;
}): Promise<DispatchResult> {
  const subject = 'Welcome to InterviewIQ — Your Adaptive Assessment Workspace is Ready';
  const appUrl = getAppBaseUrl();
  const html = wrapEmailLayout(
    'Account Registration Confirmation',
    `<p>Hi ${params.fullName},</p>
     <p>Welcome to <strong>InterviewIQ</strong>. Your student profile has been successfully created and linked to your adaptive interview workspace.</p>
     <p>Here is what you can do next:</p>
     <ul style="padding-left: 20px;">
       <li>Configure a role-specific Technical, HR, or Mixed mock interview.</li>
       <li>Experience real-time difficulty adaptation based on your answer scores.</li>
       <li>Track topic-wise mastery and download detailed PDF performance reports.</li>
     </ul>
     <p style="margin-top: 24px;">
       <a href="${appUrl}" style="display: inline-block; background: #1d4ed8; color: #ffffff; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: 600;">Go to Dashboard</a>
     </p>`
  );
  const text = `Hi ${params.fullName},\n\nWelcome to InterviewIQ! Your account is ready. Visit ${appUrl} to start your first adaptive mock interview.`;

  const result = await dispatchEmail({ to: params.email, subject, html, text });
  await logEmailNotification({
    userId: params.userId,
    userUid: params.userUid,
    recipientEmail: params.email,
    eventType: 'registration',
    subject,
    result,
  });
  return result;
}

export async function sendPasswordResetNotificationEmail(params: {
  email: string;
  resetLink?: string;
}): Promise<DispatchResult> {
  const subject = 'InterviewIQ Password Reset Request';
  const linkBlock = params.resetLink
    ? `<p style="margin: 20px 0;"><a href="${params.resetLink}" style="display: inline-block; background: #1d4ed8; color: #ffffff; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: 600;">Reset Password</a></p>
       <p style="font-size: 12px; color: #64748b;">Or copy this link: ${params.resetLink}</p>`
    : `<p>A password reset request was initiated for your InterviewIQ account. Please follow the instructions in the authentication recovery message sent to your inbox.</p>`;

  const html = wrapEmailLayout(
    'Security & Password Recovery',
    `<p>Hello,</p>
     <p>We received a request to reset the password for your InterviewIQ account (<strong>${params.email}</strong>).</p>
     ${linkBlock}
     <p>If you did not request this change, you can safely ignore this message.</p>`
  );
  const text = params.resetLink
    ? `Reset your InterviewIQ password using this link: ${params.resetLink}`
    : `A password reset request was initiated for your InterviewIQ account (${params.email}).`;

  const result = await dispatchEmail({ to: params.email, subject, html, text });
  await logEmailNotification({
    recipientEmail: params.email,
    eventType: 'password_reset',
    subject,
    result,
  });
  return result;
}

export async function sendInterviewCompletionEmail(params: {
  userId: number;
  userUid: string;
  email: string;
  fullName: string;
  interviewId: number;
  jobRole: string;
  category: string;
  totalScore: number;
  maxScore: number;
  percentage: number;
  durationSeconds: number;
  strengths: string[];
  weakTopics: string[];
}): Promise<DispatchResult> {
  const subject = `InterviewIQ Report: ${params.jobRole} (${params.percentage.toFixed(1)}%)`;
  const appUrl = getAppBaseUrl();
  const minutes = Math.max(1, Math.round(params.durationSeconds / 60));

  const html = wrapEmailLayout(
    'Interview Completion Summary',
    `<p>Hi ${params.fullName},</p>
     <p>You completed your <strong>${params.category}</strong> mock interview for <strong>${params.jobRole}</strong>.</p>
     <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin: 18px 0;">
       <div style="font-size: 13px; color: #64748b;">Overall Score</div>
       <div style="font-size: 24px; font-weight: 700; color: #0f172a; margin-top: 2px;">${params.totalScore.toFixed(1)} / ${params.maxScore} (${params.percentage.toFixed(1)}%)</div>
       <div style="font-size: 13px; color: #475569; margin-top: 6px;">Duration: ${minutes} min</div>
     </div>
     <p><strong>Strong Areas:</strong> ${params.strengths.length > 0 ? params.strengths.join(', ') : 'Keep practicing to build topic benchmarks'}</p>
     <p><strong>Focus Topics Next:</strong> ${params.weakTopics.length > 0 ? params.weakTopics.join(', ') : 'All evaluated topics scored well!'}</p>
     <p style="margin-top: 24px;">
       <a href="${appUrl}" style="display: inline-block; background: #1d4ed8; color: #ffffff; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: 600;">View Full Performance Report</a>
     </p>`
  );
  const text = `Hi ${params.fullName},\n\nYou completed your ${params.category} (${params.jobRole}) interview on InterviewIQ.\nScore: ${params.totalScore.toFixed(1)} / ${params.maxScore} (${params.percentage.toFixed(1)}%)\nDuration: ${minutes} min\nFocus Topics: ${params.weakTopics.join(', ') || 'None'}\n\nVisit ${appUrl} to inspect your detailed breakdown and download the PDF report.`;

  const result = await dispatchEmail({ to: params.email, subject, html, text });
  await logEmailNotification({
    userId: params.userId,
    userUid: params.userUid,
    recipientEmail: params.email,
    eventType: 'interview_completed',
    subject,
    result,
  });
  return result;
}
