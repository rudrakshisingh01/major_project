import { questions } from '../db/schema.ts';

export type DifficultyLevel = 'Beginner' | 'Intermediate' | 'Advanced';

const DIFFICULTY_LADDER: DifficultyLevel[] = ['Beginner', 'Intermediate', 'Advanced'];

export interface AdaptiveDecision {
  previousDifficulty: DifficultyLevel;
  nextDifficulty: DifficultyLevel;
  action: 'increase' | 'maintain' | 'decrease';
  message: string;
}

export function normalizeDifficulty(value: string): DifficultyLevel {
  if (value === 'Advanced') return 'Advanced';
  if (value === 'Intermediate') return 'Intermediate';
  return 'Beginner';
}

export function computeNextDifficulty(
  currentDifficultyInput: string,
  scorePercentage: number
): AdaptiveDecision {
  const currentDifficulty = normalizeDifficulty(currentDifficultyInput);
  const currentIndex = DIFFICULTY_LADDER.indexOf(currentDifficulty);

  if (scorePercentage >= 80) {
    if (currentIndex < DIFFICULTY_LADDER.length - 1) {
      const nextDifficulty = DIFFICULTY_LADDER[currentIndex + 1];
      return {
        previousDifficulty: currentDifficulty,
        nextDifficulty,
        action: 'increase',
        message: `Excellent performance! Your next question will be more challenging (${nextDifficulty}).`,
      };
    }
    return {
      previousDifficulty: currentDifficulty,
      nextDifficulty: 'Advanced',
      action: 'maintain',
      message:
        'Excellent performance! You are already at Advanced difficulty—maintaining peak challenge.',
    };
  }

  if (scorePercentage >= 40) {
    return {
      previousDifficulty: currentDifficulty,
      nextDifficulty: currentDifficulty,
      action: 'maintain',
      message: `Steady performance (${Math.round(scorePercentage)}%). Maintaining ${currentDifficulty} difficulty to build consistency.`,
    };
  }

  if (currentIndex > 0) {
    const nextDifficulty = DIFFICULTY_LADDER[currentIndex - 1];
    return {
      previousDifficulty: currentDifficulty,
      nextDifficulty,
      action: 'decrease',
      message: `Score below 40%. Adjusting to ${nextDifficulty} difficulty to reinforce foundational concepts.`,
    };
  }

  return {
    previousDifficulty: currentDifficulty,
    nextDifficulty: 'Beginner',
    action: 'maintain',
    message: 'Staying at Beginner level so you can solidify core fundamentals before advancing.',
  };
}

export type QuestionRow = typeof questions.$inferSelect;

function pickPreferredTopic(
  candidates: QuestionRow[],
  coveredTopics: Record<string, number>
): QuestionRow {
  // Prefer topics with fewer questions asked so far in this interview
  const sorted = [...candidates].sort((a, b) => {
    const countA = coveredTopics[a.topic] ?? 0;
    const countB = coveredTopics[b.topic] ?? 0;
    if (countA !== countB) return countA - countB;
    return a.id - b.id;
  });

  // Take from the least-covered topic group with slight randomness among top 3 ties
  const minCount = coveredTopics[sorted[0].topic] ?? 0;
  const tiedTop = sorted.filter((q) => (coveredTopics[q.topic] ?? 0) === minCount);
  const pickIndex = Math.floor(Math.random() * Math.min(tiedTop.length, 3));
  return tiedTop[pickIndex];
}

export function selectNextAdaptiveQuestion(params: {
  allQuestions: QuestionRow[];
  usedQuestionIds: Set<number>;
  coveredTopics: Record<string, number>;
  targetDifficulty: DifficultyLevel;
  jobRole: string;
  interviewCategory: string; // 'Technical Interview' | 'HR Interview' | 'Mixed Interview'
  questionOrder: number; // 1-based
  totalQuestions: number;
}): QuestionRow | null {
  const {
    allQuestions,
    usedQuestionIds,
    coveredTopics,
    targetDifficulty,
    jobRole,
    interviewCategory,
    questionOrder,
  } = params;

  const unused = allQuestions.filter((q) => !usedQuestionIds.has(q.id));
  if (unused.length === 0) return null;

  // Determine desired question category for this slot
  let desiredCategory: 'Technical Interview' | 'HR Interview' | null = null;
  if (interviewCategory === 'Technical Interview') {
    desiredCategory = 'Technical Interview';
  } else if (interviewCategory === 'HR Interview') {
    desiredCategory = 'HR Interview';
  } else if (interviewCategory === 'Mixed Interview') {
    // Every 3rd question is HR (~30%), otherwise Technical (~70%)
    desiredCategory = questionOrder % 3 === 0 ? 'HR Interview' : 'Technical Interview';
  }

  const categoryPool =
    desiredCategory !== null
      ? unused.filter((q) => q.category === desiredCategory)
      : unused;

  // Fallback if desired category pool ran out (e.g. long HR or Mixed interview)
  const effectivePool = categoryPool.length > 0 ? categoryPool : unused;

  const matchesRole = (q: QuestionRow) =>
    q.jobRole === jobRole ||
    (Array.isArray(q.applicableRoles) && q.applicableRoles.includes(jobRole));

  // Tier 1: Exact difficulty + matching job role
  const tier1 = effectivePool.filter(
    (q) => q.difficulty === targetDifficulty && matchesRole(q)
  );
  if (tier1.length > 0) return pickPreferredTopic(tier1, coveredTopics);

  // Tier 2: Exact difficulty + any role in category
  const tier2 = effectivePool.filter((q) => q.difficulty === targetDifficulty);
  if (tier2.length > 0) return pickPreferredTopic(tier2, coveredTopics);

  // Tier 3: Adjacent difficulty + matching job role
  const adjacentDifficulties: DifficultyLevel[] =
    targetDifficulty === 'Beginner'
      ? ['Intermediate', 'Advanced']
      : targetDifficulty === 'Advanced'
      ? ['Intermediate', 'Beginner']
      : ['Beginner', 'Advanced'];

  for (const adj of adjacentDifficulties) {
    const tier3 = effectivePool.filter((q) => q.difficulty === adj && matchesRole(q));
    if (tier3.length > 0) return pickPreferredTopic(tier3, coveredTopics);
  }

  // Tier 4: Adjacent difficulty + any role
  for (const adj of adjacentDifficulties) {
    const tier4 = effectivePool.filter((q) => q.difficulty === adj);
    if (tier4.length > 0) return pickPreferredTopic(tier4, coveredTopics);
  }

  // Tier 5: Any unused question
  return pickPreferredTopic(effectivePool, coveredTopics);
}
