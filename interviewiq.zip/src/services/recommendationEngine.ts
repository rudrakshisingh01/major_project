import { desc, eq } from 'drizzle-orm';
import { db } from '../db/index.ts';
import { interviews, performanceRecords, questions } from '../db/schema.ts';

export interface TopicRecommendation {
  topic: string;
  averageScore: number;
  accuracyPercentage: number;
  attempts: number;
  priority: 'High' | 'Medium' | 'Maintain';
  recommendedDifficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  reason: string;
}

export interface RecommendedQuestionItem {
  id: number;
  questionCode: string;
  questionText: string;
  topic: string;
  difficulty: string;
  jobRole: string;
}

export interface PersonalizedRecommendations {
  suggestedDifficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  overallReadinessLevel: string;
  scoreTrendDelta: number | null;
  preparationSummary: string;
  weakTopics: TopicRecommendation[];
  strongTopics: TopicRecommendation[];
  recommendedQuestions: RecommendedQuestionItem[];
}

export async function generatePersonalizedRecommendations(
  userUid: string,
  targetRole: string
): Promise<PersonalizedRecommendations> {
  const userInterviews = await db
    .select()
    .from(interviews)
    .where(eq(interviews.userUid, userUid))
    .orderBy(desc(interviews.startedAt));

  const completedInterviews = userInterviews.filter((i) => i.status === 'completed');

  const records = await db
    .select()
    .from(performanceRecords)
    .where(eq(performanceRecords.userUid, userUid));

  const allQuestions = await db.select().from(questions);

  if (completedInterviews.length === 0) {
    const starterQuestions = allQuestions
      .filter(
        (q) =>
          q.difficulty === 'Beginner' &&
          (q.jobRole === targetRole ||
            (Array.isArray(q.applicableRoles) && q.applicableRoles.includes(targetRole)))
      )
      .slice(0, 6);

    return {
      suggestedDifficulty: 'Beginner',
      overallReadinessLevel: 'Onboarding Baseline',
      scoreTrendDelta: null,
      preparationSummary: `Complete your first adaptive mock interview for ${targetRole} to unlock topic-by-topic diagnostics, accuracy trends, and weak-area practice plans.`,
      weakTopics: [],
      strongTopics: [],
      recommendedQuestions: starterQuestions.map((q) => ({
        id: q.id,
        questionCode: q.questionCode,
        questionText: q.questionText,
        topic: q.topic,
        difficulty: q.difficulty,
        jobRole: q.jobRole,
      })),
    };
  }

  // Compute trend delta between most recent and previous interview
  let scoreTrendDelta: number | null = null;
  if (completedInterviews.length >= 2) {
    scoreTrendDelta = Number(
      (completedInterviews[0].percentage - completedInterviews[1].percentage).toFixed(1)
    );
  }

  // Moving average of recent up to 3 interviews
  const recentSlice = completedInterviews.slice(0, 3);
  const recentAvgPct =
    recentSlice.reduce((sum, item) => sum + item.percentage, 0) / recentSlice.length;

  let suggestedDifficulty: 'Beginner' | 'Intermediate' | 'Advanced' = 'Beginner';
  let overallReadinessLevel = 'Foundation Builder';
  if (recentAvgPct >= 78) {
    suggestedDifficulty = 'Advanced';
    overallReadinessLevel = 'Interview Ready';
  } else if (recentAvgPct >= 52) {
    suggestedDifficulty = 'Intermediate';
    overallReadinessLevel = 'Progressing Competently';
  }

  // Aggregate topic performance
  const topicMap = new Map<
    string,
    { totalScore: number; totalQuestions: number; correctCount: number; attempts: number }
  >();

  for (const rec of records) {
    const entry = topicMap.get(rec.topic) ?? {
      totalScore: 0,
      totalQuestions: 0,
      correctCount: 0,
      attempts: 0,
    };
    entry.totalScore += rec.averageScore * rec.questionsAttempted;
    entry.totalQuestions += rec.questionsAttempted;
    entry.correctCount += rec.correctCount;
    entry.attempts += 1;
    topicMap.set(rec.topic, entry);
  }

  const weakTopics: TopicRecommendation[] = [];
  const strongTopics: TopicRecommendation[] = [];

  for (const [topic, stats] of topicMap.entries()) {
    const avgScore = stats.totalQuestions > 0 ? stats.totalScore / stats.totalQuestions : 0;
    const accuracy =
      stats.totalQuestions > 0 ? (stats.correctCount / stats.totalQuestions) * 100 : 0;

    const recDifficulty: 'Beginner' | 'Intermediate' | 'Advanced' =
      avgScore >= 7.5 ? 'Advanced' : avgScore >= 5.0 ? 'Intermediate' : 'Beginner';

    if (avgScore < 6.5 || accuracy < 60) {
      weakTopics.push({
        topic,
        averageScore: Number(avgScore.toFixed(1)),
        accuracyPercentage: Number(accuracy.toFixed(1)),
        attempts: stats.totalQuestions,
        priority: avgScore < 4.5 ? 'High' : 'Medium',
        recommendedDifficulty: recDifficulty,
        reason:
          avgScore < 4.5
            ? `Average score is ${avgScore.toFixed(1)}/10 across ${stats.totalQuestions} question(s). Focus on core definitions and required terminology.`
            : `Accuracy at ${accuracy.toFixed(0)}%. Practice structured explanations covering trade-offs and missing rubric keywords.`,
      });
    } else {
      strongTopics.push({
        topic,
        averageScore: Number(avgScore.toFixed(1)),
        accuracyPercentage: Number(accuracy.toFixed(1)),
        attempts: stats.totalQuestions,
        priority: 'Maintain',
        recommendedDifficulty: recDifficulty,
        reason: `Consistent mastery (${avgScore.toFixed(1)}/10). Ready for ${recDifficulty} edge-case questions.`,
      });
    }
  }

  weakTopics.sort((a, b) => a.averageScore - b.averageScore);
  strongTopics.sort((a, b) => b.averageScore - a.averageScore);

  // Recommend concrete questions targeting weak topics first
  const weakTopicNames = new Set(weakTopics.map((w) => w.topic));
  const weakCandidates = allQuestions.filter((q) => weakTopicNames.has(q.topic));
  const fallbackCandidates = allQuestions.filter(
    (q) =>
      q.difficulty === suggestedDifficulty &&
      (q.jobRole === targetRole ||
        (Array.isArray(q.applicableRoles) && q.applicableRoles.includes(targetRole)))
  );

  const recommendedPool =
    weakCandidates.length >= 4
      ? weakCandidates
      : [...weakCandidates, ...fallbackCandidates].slice(0, 8);

  const uniqueQuestions = Array.from(
    new Map(recommendedPool.map((q) => [q.id, q])).values()
  ).slice(0, 6);

  const topWeakText =
    weakTopics.length > 0
      ? `Prioritize ${weakTopics
          .slice(0, 2)
          .map((w) => w.topic)
          .join(' and ')} to lift your overall readiness.`
      : 'You have no critical weak topics right now—challenge yourself with Advanced-level mixed sessions.';

  const trendText =
    scoreTrendDelta !== null
      ? scoreTrendDelta >= 0
        ? `Your latest session improved by +${scoreTrendDelta}% compared to the previous attempt.`
        : `Your latest session dipped by ${scoreTrendDelta}% compared to the previous attempt.`
      : 'Complete one more session to unlock multi-attempt progression tracking.';

  const preparationSummary = `Based on ${completedInterviews.length} completed interview(s) with a recent average of ${recentAvgPct.toFixed(1)}%, your recommended starting tier is ${suggestedDifficulty}. ${trendText} ${topWeakText}`;

  return {
    suggestedDifficulty,
    overallReadinessLevel,
    scoreTrendDelta,
    preparationSummary,
    weakTopics,
    strongTopics,
    recommendedQuestions: uniqueQuestions.map((q) => ({
      id: q.id,
      questionCode: q.questionCode,
      questionText: q.questionText,
      topic: q.topic,
      difficulty: q.difficulty,
      jobRole: q.jobRole,
    })),
  };
}
