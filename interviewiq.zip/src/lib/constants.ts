export const JOB_ROLES = [
  'Frontend Developer',
  'Backend Developer',
  'Full Stack Developer',
  'Java Developer',
  'Python Developer',
  'C++ Developer',
  'Data Analyst',
  'Software Engineer',
] as const;

export const INTERVIEW_CATEGORIES = [
  'Technical Interview',
  'HR Interview',
  'Mixed Interview',
] as const;

export const DIFFICULTY_LEVELS = ['Beginner', 'Intermediate', 'Advanced'] as const;

export const QUESTION_COUNTS = [5, 10, 15, 20] as const;

export const TOPICS = [
  'Data Structures and Algorithms',
  'C++ Programming',
  'Java Programming',
  'Python Programming',
  'DBMS and SQL',
  'Operating Systems',
  'Computer Networks',
  'OOP Concepts',
  'HTML, CSS and JavaScript',
  'React.js',
  'Node.js',
  'HR and Behavioral',
] as const;
