import { jsPDF } from 'jspdf';

export interface ReportQuestionItem {
  questionOrder: number;
  difficultyAtTime: string;
  userAnswer: string;
  score: number;
  maxMarks: number;
  correctnessLevel: string;
  feedback: string;
  missingConcepts: string[];
  timeSpentSeconds: number;
  question: {
    questionText: string;
    topic: string;
    category: string;
    expectedAnswer: string;
  };
}

export interface ReportInterviewData {
  id: number;
  jobRole: string;
  category: string;
  initialDifficulty: string;
  currentDifficulty: string;
  totalQuestions: number;
  totalScore: number;
  maxScore: number;
  percentage: number;
  durationSeconds: number;
  startedAt: string;
  completedAt: string | null;
}

export function downloadInterviewReportPdf(
  candidateName: string,
  interview: ReportInterviewData,
  items: ReportQuestionItem[],
  strengths: string[],
  weaknesses: string[]
) {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 44;
  const maxWidth = pageWidth - margin * 2;
  let y = 48;

  const ensureSpace = (needed: number) => {
    if (y + needed > pageHeight - 48) {
      doc.addPage();
      y = 48;
    }
  };

  // Navy Header Banner
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageWidth, 88, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(20);
  doc.text('InterviewIQ', margin, 38);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.setTextColor(203, 213, 225);
  doc.text('Adaptive Interview Assessment & Performance Report', margin, 58);
  doc.text(
    `Generated: ${new Date(interview.completedAt || interview.startedAt).toLocaleDateString()}`,
    pageWidth - margin,
    58,
    { align: 'right' }
  );

  y = 114;

  // Candidate & Session Metadata
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text(`${interview.jobRole} — ${interview.category}`, margin, y);
  y += 18;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(71, 85, 105);
  const minutes = Math.floor(interview.durationSeconds / 60);
  const secs = interview.durationSeconds % 60;
  doc.text(
    `Candidate: ${candidateName}   |   Difficulty: ${interview.initialDifficulty} -> ${interview.currentDifficulty}   |   Duration: ${minutes}m ${secs}s`,
    margin,
    y
  );
  y += 22;

  // Summary Metrics Box
  doc.setDrawColor(226, 232, 240);
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(margin, y, maxWidth, 56, 6, 6, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);

  const avgTime = items.length > 0 ? Math.round(interview.durationSeconds / items.length) : 0;
  const colW = maxWidth / 4;
  const metrics = [
    { label: 'Overall Score', val: `${interview.totalScore.toFixed(1)} / ${interview.maxScore}` },
    { label: 'Percentage', val: `${interview.percentage.toFixed(1)}%` },
    { label: 'Questions', val: `${items.length} / ${interview.totalQuestions}` },
    { label: 'Avg Time / Q', val: `${avgTime}s` },
  ];

  metrics.forEach((m, i) => {
    const x = margin + colW * i + 14;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.text(m.label, x, y + 20);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text(m.val, x, y + 40);
  });

  y += 78;

  // Strengths & Weaknesses
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('Strengths & Focus Areas', margin, y);
  y += 16;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(51, 65, 85);
  const strengthLine = `Strong Topics: ${strengths.length > 0 ? strengths.join(', ') : 'Baseline established — keep building consistency'}`;
  const weakLine = `Topics to Improve: ${weaknesses.length > 0 ? weaknesses.join(', ') : 'No weak topics flagged in this session'}`;
  const splitS = doc.splitTextToSize(strengthLine, maxWidth);
  const splitW = doc.splitTextToSize(weakLine, maxWidth);
  doc.text(splitS, margin, y);
  y += splitS.length * 14 + 4;
  doc.text(splitW, margin, y);
  y += splitW.length * 14 + 16;

  // Question-by-Question Breakdown
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text('Question-by-Question Evaluation', margin, y);
  y += 16;

  for (const item of items) {
    ensureSpace(120);
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, pageWidth - margin, y);
    y += 14;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(29, 78, 216);
    doc.text(
      `Q${item.questionOrder} · ${item.question.topic} · ${item.difficultyAtTime} · Score: ${item.score.toFixed(1)}/${item.maxMarks} (${item.correctnessLevel})`,
      margin,
      y
    );
    y += 14;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42);
    const qLines = doc.splitTextToSize(item.question.questionText, maxWidth);
    ensureSpace(qLines.length * 13 + 30);
    doc.text(qLines, margin, y);
    y += qLines.length * 13 + 6;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(51, 65, 85);
    const ansText = `Your Answer: ${item.userAnswer || '(No answer submitted)'}`;
    const ansLines = doc.splitTextToSize(ansText, maxWidth);
    ensureSpace(ansLines.length * 12 + 24);
    doc.text(ansLines, margin, y);
    y += ansLines.length * 12 + 4;

    const fbLines = doc.splitTextToSize(`Feedback: ${item.feedback}`, maxWidth);
    ensureSpace(fbLines.length * 12 + 20);
    doc.text(fbLines, margin, y);
    y += fbLines.length * 12 + 10;
  }

  doc.save(`InterviewIQ_Report_${interview.jobRole.replace(/\s+/g, '_')}_${interview.id}.pdf`);
}
