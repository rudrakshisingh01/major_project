import { relations } from 'drizzle-orm';
import {
  boolean,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from 'drizzle-orm/pg-core';

export interface AdaptiveHistoryStep {
  step: number;
  difficulty: string;
  scorePercent: number | null;
  action: 'initial' | 'increase' | 'maintain' | 'decrease';
  message: string;
}

export interface ScoreBreakdown {
  keywordRelevance: number;
  conceptualUnderstanding: number;
  completeness: number;
  relevance: number;
}

export const profiles = pgTable('profiles', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email').notNull(),
  fullName: text('full_name').notNull().default('Student'),
  targetRole: text('target_role').notNull().default('Software Engineer'),
  collegeName: text('college_name').notNull().default('B.Tech Computer Science'),
  graduationYear: text('graduation_year').notNull().default('2026'),
  experienceLevel: text('experience_level').notNull().default('Beginner'),
  bio: text('bio').notNull().default('Preparing for technical and behavioral campus placements.'),
  emailAlertsEnabled: boolean('email_alerts_enabled').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const emailNotifications = pgTable('email_notifications', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => profiles.id, { onDelete: 'cascade' }),
  userUid: text('user_uid'),
  recipientEmail: text('recipient_email').notNull(),
  eventType: text('event_type').notNull(), // 'registration' | 'password_reset' | 'interview_completed'
  subject: text('subject').notNull(),
  provider: text('provider').notNull(), // 'resend' | 'smtp' | 'local_outbox'
  deliveryStatus: text('delivery_status').notNull(), // 'sent' | 'logged' | 'failed'
  providerMessageId: text('provider_message_id'),
  errorMessage: text('error_message'),
  sentAt: timestamp('sent_at').defaultNow().notNull(),
});

export const questions = pgTable('questions', {
  id: serial('id').primaryKey(),
  questionCode: text('question_code').notNull().unique(),
  questionText: text('question_text').notNull(),
  topic: text('topic').notNull(),
  jobRole: text('job_role').notNull(),
  applicableRoles: jsonb('applicable_roles').$type<string[]>().notNull().default([]),
  category: text('category').notNull(), // 'Technical Interview' | 'HR Interview'
  difficulty: text('difficulty').notNull(), // 'Beginner' | 'Intermediate' | 'Advanced'
  expectedAnswer: text('expected_answer').notNull(),
  evaluationKeywords: jsonb('evaluation_keywords').$type<string[]>().notNull().default([]),
  evaluationCriteria: text('evaluation_criteria').notNull(),
  marks: integer('marks').notNull().default(10),
  createdByUid: text('created_by_uid'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const interviews = pgTable('interviews', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => profiles.id, { onDelete: 'cascade' })
    .notNull(),
  userUid: text('user_uid').notNull(),
  jobRole: text('job_role').notNull(),
  category: text('category').notNull(), // 'Technical Interview' | 'HR Interview' | 'Mixed Interview'
  initialDifficulty: text('initial_difficulty').notNull(),
  currentDifficulty: text('current_difficulty').notNull(),
  totalQuestions: integer('total_questions').notNull(),
  answeredCount: integer('answered_count').notNull().default(0),
  timeLimitMinutes: integer('time_limit_minutes').notNull(),
  durationSeconds: integer('duration_seconds').notNull().default(0),
  status: text('status').notNull().default('in_progress'), // 'in_progress' | 'completed' | 'abandoned'
  totalScore: real('total_score').notNull().default(0),
  maxScore: real('max_score').notNull().default(0),
  percentage: real('percentage').notNull().default(0),
  adaptiveHistory: jsonb('adaptive_history')
    .$type<AdaptiveHistoryStep[]>()
    .notNull()
    .default([]),
  startedAt: timestamp('started_at').defaultNow().notNull(),
  completedAt: timestamp('completed_at'),
});

export const interviewAnswers = pgTable('interview_answers', {
  id: serial('id').primaryKey(),
  interviewId: integer('interview_id')
    .references(() => interviews.id, { onDelete: 'cascade' })
    .notNull(),
  questionId: integer('question_id')
    .references(() => questions.id)
    .notNull(),
  userUid: text('user_uid').notNull(),
  questionOrder: integer('question_order').notNull(),
  difficultyAtTime: text('difficulty_at_time').notNull(),
  userAnswer: text('user_answer').notNull().default(''),
  draftAnswer: text('draft_answer').notNull().default(''),
  score: real('score').notNull().default(0),
  maxMarks: integer('max_marks').notNull().default(10),
  isSubmitted: boolean('is_submitted').notNull().default(false),
  correctnessLevel: text('correctness_level').notNull().default('Pending'),
  feedback: text('feedback').notNull().default(''),
  matchedKeywords: jsonb('matched_keywords').$type<string[]>().notNull().default([]),
  missingConcepts: jsonb('missing_concepts').$type<string[]>().notNull().default([]),
  suggestedImprovements: text('suggested_improvements').notNull().default(''),
  scoreBreakdown: jsonb('score_breakdown')
    .$type<ScoreBreakdown>()
    .notNull()
    .default({
      keywordRelevance: 0,
      conceptualUnderstanding: 0,
      completeness: 0,
      relevance: 0,
    }),
  adaptiveMessage: text('adaptive_message').notNull().default(''),
  nextDifficulty: text('next_difficulty').notNull().default('Beginner'),
  timeSpentSeconds: integer('time_spent_seconds').notNull().default(0),
  answeredAt: timestamp('answered_at').defaultNow().notNull(),
});

export const performanceRecords = pgTable('performance_records', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => profiles.id, { onDelete: 'cascade' })
    .notNull(),
  userUid: text('user_uid').notNull(),
  interviewId: integer('interview_id')
    .references(() => interviews.id, { onDelete: 'cascade' })
    .notNull(),
  topic: text('topic').notNull(),
  category: text('category').notNull(),
  difficulty: text('difficulty').notNull(),
  questionsAttempted: integer('questions_attempted').notNull(),
  correctCount: integer('correct_count').notNull(),
  averageScore: real('average_score').notNull(),
  accuracyPercentage: real('accuracy_percentage').notNull(),
  avgTimeSeconds: real('avg_time_seconds').notNull(),
  recordedAt: timestamp('recorded_at').defaultNow().notNull(),
});

export const profilesRelations = relations(profiles, ({ many }) => ({
  interviews: many(interviews),
  performanceRecords: many(performanceRecords),
}));

export const interviewsRelations = relations(interviews, ({ one, many }) => ({
  profile: one(profiles, {
    fields: [interviews.userId],
    references: [profiles.id],
  }),
  answers: many(interviewAnswers),
  performanceRecords: many(performanceRecords),
}));

export const interviewAnswersRelations = relations(interviewAnswers, ({ one }) => ({
  interview: one(interviews, {
    fields: [interviewAnswers.interviewId],
    references: [interviews.id],
  }),
  question: one(questions, {
    fields: [interviewAnswers.questionId],
    references: [questions.id],
  }),
}));

export const performanceRecordsRelations = relations(performanceRecords, ({ one }) => ({
  profile: one(profiles, {
    fields: [performanceRecords.userId],
    references: [profiles.id],
  }),
  interview: one(interviews, {
    fields: [performanceRecords.interviewId],
    references: [interviews.id],
  }),
}));
