import { eq } from 'drizzle-orm';
import { db } from './index.ts';
import { profiles } from './schema.ts';

export async function getOrCreateProfile(
  uid: string,
  email: string,
  fullName?: string
) {
  try {
    const existing = await db
      .select()
      .from(profiles)
      .where(eq(profiles.uid, uid))
      .limit(1);

    if (existing.length > 0) {
      return existing[0];
    }

    const derivedName =
      fullName && fullName.trim().length > 0
        ? fullName.trim()
        : email.split('@')[0] || 'Student';

    const inserted = await db
      .insert(profiles)
      .values({
        uid,
        email,
        fullName: derivedName,
      })
      .onConflictDoUpdate({
        target: profiles.uid,
        set: {
          email,
          updatedAt: new Date(),
        },
      })
      .returning();

    return inserted[0];
  } catch (error) {
    console.error('Failed to get or create user profile:', error);
    throw new Error('Failed to load user profile.', { cause: error });
  }
}

export async function updateProfileByUid(
  uid: string,
  data: {
    fullName?: string;
    targetRole?: string;
    collegeName?: string;
    graduationYear?: string;
    experienceLevel?: string;
    bio?: string;
  }
) {
  try {
    const updated = await db
      .update(profiles)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(profiles.uid, uid))
      .returning();

    return updated[0] ?? null;
  } catch (error) {
    console.error('Failed to update user profile:', error);
    throw new Error('Failed to update user profile.', { cause: error });
  }
}
